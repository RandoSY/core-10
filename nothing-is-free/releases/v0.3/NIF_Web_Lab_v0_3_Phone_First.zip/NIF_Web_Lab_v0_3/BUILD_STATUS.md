# BUILD STATUS — NIF Web Lab v0.3

**Release:** 0.3.0 — Phone-First Edition  
**Status:** runnable reference build

## Implemented

- Phone charging is CORE10-3.00 and the default first lab.
- Public/login page is rebuilt around the phone-charging hero and CORE 10 visual language.
- Interactive phone simulator exposes V, A, W, Wh, SOC, wall input, battery storage, losses, background phone use and cost.
- Existing NIF labs remain intact as subsidiary extensions.
- Persistent accounts, SQLite learner model, multimodal evidence, inquiry cycles, instructor dashboard and Teacher Soul runtime remain intact.
- Seed metadata can update an existing v0.2 database without deleting learner evidence.

## Validation required before public SaaS use

- Production identity/SSO, HTTPS, Postgres, object storage and backups.
- Browser/device matrix and accessibility audit.
- FERPA/COPPA and school data-governance review as applicable.
- Calibrate simplified phone model against several physical phones/chargers/USB meters.
- Replace disabled SSO mock buttons with configured providers.
