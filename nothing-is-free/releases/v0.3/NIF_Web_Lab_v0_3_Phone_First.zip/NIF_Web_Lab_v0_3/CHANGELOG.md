# Changelog

## v0.3.0 — Phone-First Edition

- Made phone charging the canonical NIF entry experience and CORE10-3.00.
- Added a browser phone-charging simulator with charger taper, losses, background phone load, V/A/W/Wh readings, energy ledger, and cost.
- Reframed every later NIF module as an extension or transfer from the phone energy problem.
- Renumbered the legacy NIF sequence through CORE10-3.14.
- Rebuilt the public/login page to match the approved CORE 10 phone-charging mock-up much more closely.
- Added phone-first dashboard messaging and `START HERE` curriculum emphasis.
- Added seed-time metadata upserts so a v0.2 database adopts the v0.3 curriculum labels without losing learner records.
- Updated Teacher Soul profile with `Start with the familiar`.


## v0.2.0 — Teacher Soul Edition

- Added persistent evidence-based learner model.
- Added concept graph and NIF concept mappings.
- Added possible-misconception catalog and conservative flags.
- Added persistent six-stage inquiry cycles.
- Added phase-aware help caps.
- Added selectable AI teacher roles.
- Added Teacher Constitution / profile / diagnostics / exemplars.
- Added learner Learning Trajectory UI.
- Added instructor concept-evidence drill-down.
- Added instructor scored-evidence endpoint with independence.
- Added provenance rules for MEASURED / SIMULATED / CALCULATED / AI_INFERENCE.
- Expanded production/privacy documentation.

## v0.1.0

- Initial full-stack NIF Web Laboratory reference implementation.
