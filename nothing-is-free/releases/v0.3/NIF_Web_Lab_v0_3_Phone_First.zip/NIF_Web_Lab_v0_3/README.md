# NOTHING IS FREE — Web Laboratory v0.3

A full-stack, account-based browser laboratory for **CORE10-3: NOTHING IS FREE**, with a persistent evidence-based learner model and a configurable **Teacher Soul runtime**.

The phrase *Teacher Soul* is deliberate shorthand for something concrete: preserving a recognizable teaching practice—its priorities, questions, evidence standards, refusal rules, help policy, and diagnostic habits—in inspectable files rather than leaving pedagogy to a generic chatbot prompt.

The platform is not a toy simulation. It can stand alone as a complete web inquiry environment or pair with the physical NIF kit. Both use the same ledger:

**source → conversion → storage → useful work → losses → cost**


## v0.3 — Phone-First Edition

The curriculum now begins with a nearly universal lived experience: **charging a phone**. CORE10-3.00 is no longer an abstract ledger exercise; it is an interactive phone-charging inquiry. Everything else is organized as an extension of the same question.

- New polished public/login landing page modeled on the approved CORE 10 mock-up
- New `Charge Your Phone` simulator with:
  - starting state of charge
  - nominal battery Wh
  - charger rating
  - charging time
  - phone background load
  - simplified charge taper
  - charger and battery-path losses
  - live virtual USB V/A/W/Wh readings
  - wall Wh, battery Wh, loss Wh, and charging cost
- Phone charging is CORE10-3.00 and the default lab on login
- Existing NIF investigations are renumbered CORE10-3.01 through CORE10-3.14 and explicitly framed as transfers/extensions from the phone energy ledger
- The first curriculum card is visually marked `START HERE`
- Existing v0.2 SQLite databases are updated in place for course/module metadata instead of silently retaining the old numbering

The central teaching move is now:

**familiar act → visible measurement → energy ledger → equation → transfer to a new scale**

## v0.2 additions — the teacher becomes part of the architecture

- Machine-readable and human-readable Teacher Soul package:
  - `teacher_soul/TEACHER_CONSTITUTION.md`
  - `teacher_soul/teacher_profile.json`
  - `teacher_soul/diagnostic_patterns.json`
  - `teacher_soul/exemplar_dialogues.md`
- Persistent concept-level learner model stored in SQLite
- Explicit concept graph and NIF module-to-concept mappings
- Possible misconception flags kept separate from confirmed mastery claims
- Persistent six-stage inquiry cycles:
  - **PREDICT → COMMIT → EXPERIMENT → EXPLAIN → CHALLENGE → TRANSFER**
- Phase-aware AI assistance: the coach is intentionally more restrained during prediction/commitment
- Seven-level help ladder from silence to full explanation
- Selectable AI teaching roles:
  - Socratic coach
  - Lab partner
  - Skeptic
  - Instrument assistant
  - Data analyst
  - Assessor
  - Trajectory planner
  - Reflection coach
- Learner-facing Learning Trajectory dashboard
- Instructor evidence dashboard with concept-state and misconception summaries
- Instructor endpoint for scored evidence with an explicit independence score
- Provenance rule carried into the AI system prompt:
  - `MEASURED`
  - `SIMULATED`
  - `CALCULATED`
  - `AI_INFERENCE`

## Already included from v0.1

- Learner registration and login
- Persistent SQLite database with users, sessions, enrollments, progress, lab runs, notebook entries, uploads and event history
- Instructor role and learner roster dashboard
- Seeded CORE 10 hierarchy:
  - CORE10-1 Kitchen Inquiry Lab
  - CORE10-2 One Cup Chemistry
  - CORE10-3 NOTHING IS FREE
- Fifteen seeded NIF inquiries, CORE10-3.00 through CORE10-3.14
- Browser laboratories for:
  - complete energy ledger
  - solar irradiance / panel angle / shading / temperature
  - 4×AA NiMH charging and state of charge
  - 2WD differential-drive robot with ultrasonic obstacles and two navigation policies
  - microwave water heating and `Q = mcΔT`
  - utility-bill / marginal-vs-all-in electricity cost
- Saved simulation runs attached to user accounts
- Evidence notebook: hypothesis → observation → interpretation → next question
- Multimodal evidence library: image, audio, video, PDF, CSV/text uploads
- In-browser voice-reflection recording where MediaRecorder is supported
- Browser text-to-speech lesson reading
- Offline inquiry coach with no API key
- Optional OpenAI Responses API coach when `OPENAI_API_KEY` is set
- Optional image attachment for visual evidence
- Dockerfile + Docker Compose
- Windows and Unix start scripts
- Smoke tests

## Fastest Windows start

```bat
run_windows.bat
```

Then open:

`http://127.0.0.1:8080`

Demo accounts are seeded by default:

- learner: `student@nif.local` / `Learn2050!`
- instructor: `teacher@nif.local` / `Teach2050!`

Turn demo seeding off before public deployment.

## Manual start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Unix: source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn niflab.main:app --host 127.0.0.1 --port 8080
```

## AI teacher

The application works without an external AI service. The offline coach obeys the phase/help rules with a small deterministic response set.

To enable the external coach, set server-side environment variables:

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
```

Never put the API key in browser JavaScript.

The server builds each AI request from:

1. Teacher Constitution and calibration examples
2. selected teacher role
3. inquiry phase
4. bounded help level
5. relevant learner-model evidence
6. current module/lab state
7. optional learner image evidence

The model is therefore replaceable. The teaching doctrine is not hidden inside a particular model checkpoint.

## Learner model — what it is and is not

The database tracks concept exposure, scored evidence, independence, recent evidence, and possible misconceptions. It does **not** claim to diagnose intelligence, personality, motivation, or mental state.

Simulation runs and notebook entries count as **exposure/evidence artifacts**, but they do not automatically become mastery. Mastery changes only when scored evidence is recorded. A correct response with heavy help can be recorded differently from an independent transfer.

See `docs/LEARNER_MODEL.md`.

## Simulation versus physical validation

The Web Lab can model the entire NIF inventory and run long robot missions at accelerated time. It intentionally includes non-idealities and measurement noise. It cannot prove the exact behavior of a particular physical battery, motor, charger, ultrasonic sensor, microwave, or Chinese PCB revision.

That mismatch is part of the curriculum:

**Predict → Simulate → Experiment → Reconcile**

## Production note

v0.2 is a runnable full-stack reference platform, not yet a hardened public SaaS deployment. Before public student use, follow `docs/PRODUCTION_ROADMAP.md`: managed identity or hardened auth, HTTPS, Postgres, object storage, backups, rate limits, moderation/retention policy, FERPA/COPPA review as applicable, school/admin provisioning, audit logging, consent/retention controls for multimodal evidence, and explicit AI data-governance policy.
