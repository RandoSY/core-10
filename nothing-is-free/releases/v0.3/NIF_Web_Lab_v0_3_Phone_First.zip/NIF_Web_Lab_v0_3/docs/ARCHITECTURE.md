# NIF Web Laboratory architecture — v0.2

## Product hierarchy

```text
CORE 10 [ROOT]
├─ CORE10-1 Kitchen Inquiry Lab
├─ CORE10-2 One Cup Chemistry
└─ CORE10-3 NOTHING IS FREE
   ├─ Web Laboratory
   └─ Physical Laboratory / Personal Energy Kit
```

The Web and Physical laboratories are peers. A learner can complete the full inquiry sequence online and later confront the same model with physical evidence.

## Runtime architecture

```text
Browser SPA
  ├─ simulations / virtual instruments
  ├─ inquiry-cycle recorder
  ├─ evidence notebook
  ├─ learning-trajectory view
  ├─ media capture/upload
  ├─ voice / read-aloud
  └─ AI Teacher UI
       │ HTTPS/JSON
       ▼
FastAPI application
  ├─ session/auth service
  ├─ curriculum API
  ├─ lab-run/evidence API
  ├─ persistent learner-model service
  ├─ inquiry-cycle service
  ├─ upload service
  ├─ instructor analytics
  ├─ Teacher Soul prompt/runtime builder
  └─ AI-provider adapter
       │
       ├─ Teacher Constitution / profile / diagnostics / exemplars
       ├─ SQLite (local / pilot)
       ├─ filesystem uploads (local / pilot)
       └─ optional OpenAI Responses API
```

## The teacher is a software layer

The teaching behavior is not left to a generic LLM system prompt. The runtime explicitly assembles:

- Teacher Constitution
- role
- inquiry phase
- bounded help level
- learner evidence snapshot
- current lab/module state
- optional multimodal evidence

The AI model can be replaced without discarding the pedagogical doctrine.

## Database entities

Core platform:

- `users`: identity + role
- `sessions`: server-side login sessions + CSRF token
- `courses`: CORE 10 hierarchy
- `modules`: inquiry sequence
- `enrollments`: learner/course membership
- `progress`: module status
- `lab_runs`: complete simulation inputs/outputs for reproducibility
- `journal_entries`: hypothesis/observation/interpretation/next question
- `uploads`: multimodal evidence metadata
- `events`: audit/analytics events

Learning runtime:

- `concepts`: concept graph nodes
- `module_concepts`: module-to-concept mapping and weight
- `learner_concepts`: exposure, scored evidence, mastery estimate, independence
- `misconceptions`: inspectable misconception catalog
- `learner_misconceptions`: possible/confirmed/resolved flags
- `learning_evidence`: evidence provenance for learner-model updates
- `inquiry_cycles`: Predict → Commit → Experiment → Explain → Challenge → Transfer
- `coach_interactions`: teacher role, phase, help level, messages, reply, mode

## Shared data contract with physical SDL

The long-term physical bridge should emit the same semantic variables used by the simulator, for example:

```text
V,5.08
I,0.742
P,3.77
E_WH,8.413
RANGE_CM,84
BATTERY_V,4.91
DIST_M,17.4
```

The browser should not care whether an observation originated in a mathematical model or real hardware **for visualization and analysis**, but it must preserve provenance so the learner always knows which is which.

## Simulation philosophy

A simulation must not be a disguised answer key. It should include controllable assumptions, noise and non-idealities. Learners should be able to create bad comparisons and then diagnose them.
