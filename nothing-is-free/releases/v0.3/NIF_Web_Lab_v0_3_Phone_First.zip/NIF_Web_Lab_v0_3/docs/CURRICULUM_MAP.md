# CORE10-3 — NOTHING IS FREE Web curriculum v0.3

## The spine

**Phone charging is the canonical point of departure.** The learner begins with a nearly universal everyday act and then repeatedly asks the same accounting questions at larger scales:

**Where did the energy come from? How fast is it moving? How much accumulated? Where did it go? What was lost? What did it cost?**

| Code | Inquiry | Primary virtual instrument | Relationship to phone charging |
|---|---|---|---|
| CORE10-3.00 | Charge Your Phone | phone + USB V/A/W/Wh meter | **canonical start** |
| CORE10-3.01 | Follow the Energy Ledger | chain builder | generalize the phone path |
| CORE10-3.02 | Energy, Power, and Time | DMM / energy meter | name the quantities already seen |
| CORE10-3.03 | Flux and Irradiance | solar simulator | ask how energy reaches a panel |
| CORE10-3.04 | Flashlight to Solar Panel | solar simulator | substitute light for wall power |
| CORE10-3.05 | Catch the Sun | solar simulator | scale to sunlight |
| CORE10-3.06 | Store the Sun | NiMH charger/battery | compare storage paths |
| CORE10-3.07 | Wall versus Sun | source comparison | hold downstream task constant |
| CORE10-3.08 | Battery to Motion | robot simulator | make stored energy do visible work |
| CORE10-3.09 | Software Costs Energy | policy comparison | show decisions affect physical cost |
| CORE10-3.10 | Climb the Hill | robot/work model | connect electrical input to mgh |
| CORE10-3.11 | Microwave Water Heating | thermal model | move from ~10 W to ~1000 W scale |
| CORE10-3.12 | From Phone Charge to Electric Bill | utility bill | connect Wh to kWh and dollars |
| CORE10-3.13 | Phone → Robot → EV | transport scaling | transfer the ledger across scales |
| CORE10-3.14 | 2050 Energy Capstone | complete ledger | account for any technology |

## Repeated inquiry cycle

**PREDICT → COMMIT → EXPERIMENT → EXPLAIN → CHALLENGE → TRANSFER**

The virtual lab is a first-class inquiry environment. Physical work, when available, is used to test where the model agrees with reality and where it fails.
