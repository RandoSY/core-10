# Learner Model

## Purpose

The learner model exists to answer one question:

> What instructional move is justified by the evidence we actually have about this learner's work?

It is intentionally narrower than a psychological profile.

## Stored state

For each concept:

- exposure count
- scored evidence count
- conservative mastery estimate (0–1)
- mean independence of scored evidence
- last exposure/evidence time

For possible misconceptions:

- code and description
- status: possible / confirmed / resolved
- strength
- note and timestamps

The system also retains source artifacts:

- lab runs
- inquiry cycles
- notebook entries
- multimodal uploads
- coach interactions
- instructor assessments

## Exposure is not mastery

Running a simulation or writing a notebook entry proves participation, not understanding. Those events increment exposure and create evidence records but do not automatically raise mastery.

A mastery update requires **scored evidence**. The supplied v0.2 implementation exposes an instructor endpoint that records:

- score 0–1
- independence 0–1
- concept code
- notes

The update is intentionally conservative: a single event cannot jump a learner from zero evidence to complete mastery.

## Independence matters

A correct answer obtained after full explanation is not equivalent to an independent transfer.

The model therefore stores independence separately and includes it in the evidence-quality update.

## Misconception flags

Some coach-message heuristics can create low-strength **possible** misconception flags. They are not treated as facts. A teacher or future assessment routine must confirm or resolve them.

This protects the system from pretending that an LLM can read a learner's mind from one sentence.

## Recommendation

The current v0.2 recommender is deliberately simple: it prefers a concept the learner has encountered but has not yet secured, otherwise a new concept. A production version should add prerequisite gating, spacing, forgetting, teacher overrides, and richer assessment evidence.
