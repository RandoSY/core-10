# Phone-First Architecture

## Why the phone is the spine

The first electrical activity should not require the learner to care about an unfamiliar apparatus. Phone charging already contains source, conversion, transmission, storage, load, loss, time, power, energy and cost. NIF therefore begins with the phone and asks the learner to make the hidden energy flow visible.

## Canonical progression

1. **Experience** — the phone is at a known state of charge and gets plugged in.
2. **Observe** — a virtual USB meter exposes V, A, W and Wh.
3. **Account** — wall Wh is separated into USB output, battery storage, phone operation and losses.
4. **Name** — only now formalize P=VI and E=Pt.
5. **Transfer** — replace the wall with light; replace the phone battery with AA cells; replace the phone load with a robot; replace the robot with an EV; replace small Wh with household kWh.

## Provenance

Phone simulator readings are labeled **SIMULATED**. When a physical USB energy meter is later used, those readings are **MEASURED**. The AI teacher must preserve the distinction and use disagreement as an inquiry opportunity.
