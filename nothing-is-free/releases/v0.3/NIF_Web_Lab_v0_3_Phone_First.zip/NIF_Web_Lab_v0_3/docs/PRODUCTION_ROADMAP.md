# Production roadmap

v0.2 is intentionally complete enough to prove the product architecture, but public deployment needs a second engineering pass.

## Gate A — classroom pilot

- Keep deployment private / invite-only.
- Change `NIF_SECRET_KEY`.
- Disable demo accounts (`NIF_SEED_DEMO=0`).
- Serve through HTTPS.
- Establish daily database/upload backup.
- Define school data-retention policy.
- Freeze NIF module text and learning objectives.
- Add teacher-generated enrollment codes or admin provisioning.

## Gate B — public / multi-school service

Replace or augment:

- SQLite → PostgreSQL
- local uploads → S3-compatible object storage
- local password auth → managed OIDC / school SSO where appropriate
- one-process deployment → redundant application service
- ad-hoc logs → centralized observability

Add:

- explicit learner-model transparency/appeal controls
- AI conversation and multimodal-evidence retention controls
- model/provider change audit trail for Teacher Soul behavior
- educator controls for disabling or constraining AI roles
- email verification and password reset
- MFA for instructors/admins
- tenant / school / class entities
- roster import and class invite codes
- assignment windows and rubrics
- accessibility audit (WCAG)
- rate limiting and abuse controls
- malware scanning of uploads
- content moderation policy
- backup restore drills
- explicit privacy/retention controls
- FERPA/COPPA/legal review depending on learner ages and sales model
- full audit trails for instructor/admin actions

## Gate C — SDL physical bridge

Add a WebSocket/MQTT/serial gateway that exposes the physical NIF instruments using the same data schema as the simulation. Every observation must be tagged with provenance:

- `SIM`
- `REAL`
- `DERIVED`
- `AI_INFERRED`

That distinction should remain visible to the learner.
