# Product scope — full-bore from the start

The NIF Web Laboratory is an account-based learning product, not a single HTML simulation.

## Learner experience

- account login and persistent history
- curriculum map and progress
- accelerated simulations
- virtual instruments and full energy ledger
- saved/reproducible runs
- six-stage persistent inquiry cycle
- hypothesis/observation/interpretation notebook
- image/audio/video/document/data evidence
- voice reflection
- text-to-speech
- persistent learning trajectory
- inspectable concept evidence and possible misconception flags
- phase-aware AI teacher with selectable teaching roles
- optional image evidence for the AI teacher
- physical-lab bridge later using the same semantic measurements

## Instructor experience

- role-based login
- roster/progress summary
- concept evidence summary
- possible misconception summary
- learner drill-down
- instructor-scored evidence including independence
- future: classes, assignments, rubrics, comments, interventions, exports

## Teacher Soul layer

The product contains a versioned teaching doctrine independent of the LLM:

- constitution
- roles
- help ladder
- inquiry phases
- evidence-provenance rules
- diagnostic patterns
- calibration examples

The aim is not to imitate mannerisms. The aim is to preserve **instructional judgment**.

## Platform experience

- database-backed from day one
- API-first design
- explicit provenance for simulation vs physical evidence
- deployable locally, in Docker, or behind a cloud reverse proxy
- path to Postgres + object storage + school SSO without changing the curriculum model

## Commercial packaging

Potential product ladder:

1. **NIF Web** — complete browser inquiry course
2. **NIF Physical Kit** — reality-validation laboratory
3. **NIF Web + Kit** — full experience
4. **NIF Classroom / School** — teacher dashboard, class provisioning, shared physical stations

The web product should remain valuable even when no hardware is available.
