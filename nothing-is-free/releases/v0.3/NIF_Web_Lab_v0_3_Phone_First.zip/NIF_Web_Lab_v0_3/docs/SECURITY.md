# Security notes

Implemented in v0.2:

- PBKDF2-SHA256 password hashing with per-user salt
- server-side random sessions
- HttpOnly SameSite=Lax session cookie
- per-session CSRF token required for state-changing API calls
- role checks for instructor endpoints
- upload ownership checks
- 25 MB upload cap
- OpenAI API key remains server-side
- learner-model state is explicit database state, not hidden model memory
- instructor-only scored-evidence endpoint uses role + CSRF checks

Before internet-facing production:

- use HTTPS and `NIF_COOKIE_SECURE=1`
- replace default secret
- disable demo accounts
- implement account verification/reset flows
- add login throttling / lockout
- add MIME/file-signature validation and malware scanning
- implement tenant isolation for schools/classes
- define retention/deletion policy for AI interactions and multimodal evidence
- provide learner/guardian/institution visibility into learner-model data as appropriate
- use managed secrets
- run dependency scanning and penetration testing
