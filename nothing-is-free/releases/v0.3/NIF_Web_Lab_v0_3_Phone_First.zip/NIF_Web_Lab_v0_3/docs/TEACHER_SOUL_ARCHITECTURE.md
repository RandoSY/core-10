# Teacher Soul Architecture

## Goal

Preserve a teacher's **pedagogical judgment** as a durable, auditable software layer.

This is not literal mind uploading. The system captures the parts of teaching that can be made operational:

- what counts as evidence;
- how much help is appropriate;
- when not to answer;
- which misconceptions are worth probing;
- which questions expose reasoning;
- how to distinguish simulation, calculation, measurement, and inference;
- how to move from experience to equation;
- how to decide what the learner should do next.

## Runtime stack

```text
Teacher Constitution
        +
Teacher Profile / roles / help ladder
        +
Diagnostic patterns
        +
Exemplar teacher moves
        +
Persistent learner evidence
        +
Current inquiry phase
        +
Current lab state
        ↓
AI Teacher Runtime
        ↓
One next instructional move
```

The AI model is deliberately treated as a replaceable reasoning engine. The teaching doctrine lives in version-controlled files.

## Teaching roles

One interface can invoke different instructional functions:

- **Socratic coach** — smallest useful question
- **Lab partner** — experimental design and controls
- **Skeptic** — premise and confounder attack
- **Instrument assistant** — what an instrument can/cannot establish
- **Data analyst** — organize and analyze evidence without changing provenance
- **Assessor** — test independent understanding; avoid teaching during assessment
- **Trajectory planner** — choose the next concept/task from evidence
- **Reflection coach** — compare pre- and post-evidence explanations

## Phase-aware behavior

The same learner question should receive different responses depending on phase.

During **PREDICT**, the teacher protects the result.
During **EXPLAIN**, the teacher can scaffold more strongly.
During **CHALLENGE**, the teacher attacks assumptions.
During **TRANSFER**, the teacher changes context or scale.

The help ladder is bounded by phase, so a user request for “just tell me” cannot silently bypass the inquiry design during PREDICT/COMMIT.

## Evidence provenance

Every substantial claim should remain traceable to one of:

- `MEASURED`
- `SIMULATED`
- `CALCULATED`
- `AI_INFERENCE`

The AI can compare them. It cannot relabel one as another.

## Durability

A future generation of the platform should be able to replace:

- the LLM vendor;
- the simulation engine;
- the database backend;
- the web framework;

while preserving the Teacher Constitution, evidence schema, concept graph, inquiry cycle, and help policy.
