# Five-minute Teacher Soul demo

1. Run `run_windows.bat` and sign in as the demo learner.
2. Open **Inquiry Cycle** and write a prediction for the solar-panel angle experiment. Save with phase `PREDICT`.
3. Open **Web Lab → Solar**. Set the AI teacher to `Socratic coach`, phase `PREDICT`, help level `6`.
4. Ask: **“Just tell me what happens when I tilt the panel.”**
   - The server should cap help at level 3 for PREDICT and protect the result.
5. Run the simulation and save the lab run.
6. Switch teacher phase to `EXPLAIN` or `Skeptic` and ask why the result occurred.
7. Open **Learning Trajectory**.
   - The relevant concepts show exposure from the saved run.
   - Exposure does not automatically become mastery.
8. Sign out and sign in as the demo instructor.
9. Open **Instructor**, select the learner, and inspect the evidence model.
10. Use the instructor assessment API (or future UI) to enter scored evidence plus independence; the learner mastery estimate changes conservatively.

This demonstrates the architectural distinction:

**The LLM produces a teaching move. The application owns the teaching doctrine and the durable learner evidence.**
