# v0.3 UI reference

The approved phone-first landing-page mock-up is preserved at:

`docs/reference/CORE10_phone_first_mockup.png`

The runnable implementation is intentionally HTML/CSS rather than a flattened screenshot. The main correspondences are:

- CORE 10 public navigation bar
- dark phone-charging hero
- explicit V / A / W / Wh meter
- right-side login/create-account card
- phone-first question and call to action
- audience strip
- learning-path cards with Charge Your Phone first
- blue/navy/white visual system

The physical image is a design reference; the app should remain accessible and responsive rather than attempting pixel-for-pixel reproduction.
