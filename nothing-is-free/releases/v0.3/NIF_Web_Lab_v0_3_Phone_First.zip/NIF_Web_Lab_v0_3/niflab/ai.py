from __future__ import annotations
import base64, json, os
from .config import OPENAI_MODEL, UPLOAD_DIR
from .db import connection
from .learner_model import learner_snapshot
from .teacher_soul import build_teacher_prompt, bounded_help_level


def offline_reply(message: str, *, role: str, phase: str, help_level: int, snapshot: dict, context: dict) -> str:
    m = message.lower()
    phase = phase.upper()
    if phase in {"PREDICT","COMMIT"}:
        if "answer" in m or "tell me" in m or "what happens" in m:
            return "Commit first. Name the quantity you think will increase, decrease, or stay the same, then give one physical reason. I will audit the reasoning without revealing the result yet."
    if role == "skeptic":
        return "Before accepting that explanation, identify one variable that changed unintentionally and one result that would make your explanation fail. Which part of your statement is observation, and which part is inference?"
    if "watt" in m and ("hour" in m or "wh" in m):
        return "A watt is a rate of energy transfer. A watt-hour is an amount of energy. Put the measured power beside the elapsed time, with units, and show what quantity accumulates."
    if "mah" in m:
        return "mAh is charge capacity, not energy by itself. What is the battery voltage? Use V × Ah to estimate Wh, then tell me what assumption that estimate makes."
    if "solar" in m or "panel" in m:
        return "Start with the ledger: irradiance reaches an area, the panel converts only part of it to electrical power, and the charger/battery lose more. Change one variable—angle, shading, temperature, or irradiance—and predict the sign of the change before running it."
    if "robot" in m:
        return "Use identical battery and world conditions for the comparison. Record distance, elapsed time, turns, obstacle events, and Wh. The question is not only runtime; it is useful motion per Wh."
    if "microwave" in m:
        return "Keep wall input and water heating separate. Q = mcΔT estimates useful thermal energy in the water. Measure wall energy independently, then account for the difference instead of calling it missing."
    if role == "trajectory_planner" and snapshot.get("recommended_next_concept"):
        n = snapshot["recommended_next_concept"]
        return f"Next target: {n['title']}. Design one small task that makes the learner produce evidence for it before receiving an explanation."
    return "State a prediction, name the evidence that could prove you wrong, and label each quantity as MEASURED, SIMULATED, CALCULATED, or AI_INFERENCE. I will help with the next step, not skip the inquiry."


def ai_reply(*, user_id: int, module_id: int | None, message: str, context: dict,
             role: str = "socratic_coach", phase: str = "EXPLAIN", help_level: int | None = None,
             upload_id: int | None = None) -> tuple[str, int, str]:
    snapshot = learner_snapshot(user_id, module_id)
    phase = (phase or "EXPLAIN").upper()
    help_level = bounded_help_level(phase, help_level)
    system = build_teacher_prompt(
        role=role,
        phase=phase,
        help_level=help_level,
        learner_snapshot=snapshot,
        lab_context=context,
    )

    if not os.getenv("OPENAI_API_KEY"):
        return offline_reply(message, role=role, phase=phase, help_level=help_level, snapshot=snapshot, context=context), help_level, "offline"

    from openai import OpenAI
    client = OpenAI()
    content = [{"type":"input_text","text":message}]
    if upload_id:
        with connection() as con:
            row = con.execute("SELECT stored_name,mime_type,user_id FROM uploads WHERE id=?",(upload_id,)).fetchone()
        if row and row["user_id"] == user_id and row["mime_type"].startswith("image/"):
            p = UPLOAD_DIR / row["stored_name"]
            if p.exists() and p.stat().st_size < 8_000_000:
                data = base64.b64encode(p.read_bytes()).decode()
                content.append({"type":"input_image","image_url":f"data:{row['mime_type']};base64,{data}"})

    resp = client.responses.create(
        model=OPENAI_MODEL,
        input=[
            {"role":"system","content":[{"type":"input_text","text":system}]},
            {"role":"user","content":content},
        ],
    )
    return resp.output_text, help_level, "openai"
