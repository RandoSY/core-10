from __future__ import annotations
import hashlib, hmac, secrets
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException, Request
from .db import connection

PBKDF2_ROUNDS = 260_000
SESSION_DAYS = 14

def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    if salt_hex is None:
        salt_hex = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), PBKDF2_ROUNDS)
    return digest.hex(), salt_hex

def verify_password(password: str, expected: str, salt_hex: str) -> bool:
    actual, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(actual, expected)

def create_session(user_id: int) -> tuple[str, str, str]:
    token = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    csrf = secrets.token_urlsafe(24)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    with connection() as con:
        con.execute(
            "INSERT INTO sessions(user_id,token_hash,csrf_token,expires_at) VALUES(?,?,?,?)",
            (user_id, token_hash, csrf, expires.isoformat()),
        )
    return token, csrf, expires.isoformat()

def delete_session(token: str | None):
    if not token:
        return
    th = hashlib.sha256(token.encode()).hexdigest()
    with connection() as con:
        con.execute("DELETE FROM sessions WHERE token_hash=?", (th,))

def current_user(request: Request, required: bool = True):
    token = request.cookies.get("nif_session")
    if not token:
        if required: raise HTTPException(401, "Login required")
        return None
    th = hashlib.sha256(token.encode()).hexdigest()
    with connection() as con:
        row = con.execute(
            """SELECT u.*,s.csrf_token,s.expires_at FROM sessions s
               JOIN users u ON u.id=s.user_id WHERE s.token_hash=?""", (th,)
        ).fetchone()
        if not row:
            if required: raise HTTPException(401, "Session expired")
            return None
        if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
            con.execute("DELETE FROM sessions WHERE token_hash=?", (th,))
            if required: raise HTTPException(401, "Session expired")
            return None
        return dict(row)

def require_role(user: dict, *roles: str):
    if user["role"] not in roles:
        raise HTTPException(403, "Insufficient role")

def require_csrf(request: Request, user: dict):
    provided = request.headers.get("X-CSRF-Token", "")
    if not provided or not hmac.compare_digest(provided, user["csrf_token"]):
        raise HTTPException(403, "CSRF check failed")
