from __future__ import annotations
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("NIF_DB_PATH", str(BASE_DIR / "data" / "nif_web_lab.sqlite3")))
UPLOAD_DIR = Path(os.getenv("NIF_UPLOAD_DIR", str(BASE_DIR / "uploads")))
TEACHER_SOUL_DIR = Path(os.getenv("NIF_TEACHER_SOUL_DIR", str(BASE_DIR / "teacher_soul")))
SECRET_KEY = os.getenv("NIF_SECRET_KEY", "nif-dev-secret-change-me")
COOKIE_SECURE = os.getenv("NIF_COOKIE_SECURE", "0") == "1"
SEED_DEMO = os.getenv("NIF_SEED_DEMO", "1") == "1"
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")

DB_PATH.parent.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
