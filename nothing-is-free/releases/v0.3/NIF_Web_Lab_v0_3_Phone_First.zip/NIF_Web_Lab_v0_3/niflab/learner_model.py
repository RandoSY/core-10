from __future__ import annotations
import json
from typing import Any
from .db import connection


def ensure_learner_model(user_id: int) -> None:
    with connection() as con:
        concepts = con.execute("SELECT id FROM concepts").fetchall()
        for c in concepts:
            con.execute(
                "INSERT OR IGNORE INTO learner_concepts(user_id,concept_id) VALUES(?,?)",
                (user_id, c["id"]),
            )


def record_exposure(user_id: int, module_id: int | None, source_type: str, source_id: int | None, note: str = "") -> None:
    ensure_learner_model(user_id)
    if not module_id:
        return
    with connection() as con:
        rows = con.execute(
            """SELECT c.id,c.code FROM module_concepts mc
               JOIN concepts c ON c.id=mc.concept_id WHERE mc.module_id=?""",
            (module_id,),
        ).fetchall()
        for row in rows:
            con.execute(
                """UPDATE learner_concepts
                   SET exposure_count=exposure_count+1,last_seen_at=CURRENT_TIMESTAMP
                   WHERE user_id=? AND concept_id=?""",
                (user_id, row["id"]),
            )
            con.execute(
                """INSERT INTO learning_evidence
                   (user_id,module_id,concept_id,source_type,source_id,claim,score,independence,notes)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (user_id,module_id,row["id"],source_type,source_id,"exposure",None,None,note[:1000]),
            )


def record_scored_evidence(user_id: int, concept_code: str, score: float, independence: float,
                           source_type: str, source_id: int | None = None, module_id: int | None = None,
                           notes: str = "") -> None:
    score = max(0.0, min(1.0, float(score)))
    independence = max(0.0, min(1.0, float(independence)))
    ensure_learner_model(user_id)
    with connection() as con:
        concept = con.execute("SELECT id FROM concepts WHERE code=?", (concept_code,)).fetchone()
        if not concept:
            return
        cid = concept["id"]
        row = con.execute(
            "SELECT mastery,evidence_count,independence_mean FROM learner_concepts WHERE user_id=? AND concept_id=?",
            (user_id,cid),
        ).fetchone()
        old = float(row["mastery"] or 0)
        n = int(row["evidence_count"] or 0)
        old_ind = float(row["independence_mean"] or 0)
        # Conservative evidence update: one event cannot jump a learner to mastery.
        evidence_quality = score * (0.55 + 0.45 * independence)
        alpha = 0.18 if n < 3 else 0.10
        new_mastery = old + alpha * (evidence_quality - old)
        new_ind = (old_ind*n + independence)/(n+1)
        con.execute(
            """UPDATE learner_concepts SET mastery=?,evidence_count=evidence_count+1,
               independence_mean=?,last_evidence_at=CURRENT_TIMESTAMP,last_seen_at=CURRENT_TIMESTAMP
               WHERE user_id=? AND concept_id=?""",
            (new_mastery,new_ind,user_id,cid),
        )
        con.execute(
            """INSERT INTO learning_evidence
               (user_id,module_id,concept_id,source_type,source_id,claim,score,independence,notes)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (user_id,module_id,cid,source_type,source_id,"scored",score,independence,notes[:1000]),
        )


def flag_misconception(user_id: int, code: str, strength: float = 0.35, note: str = "") -> None:
    strength = max(0.0, min(1.0, float(strength)))
    with connection() as con:
        m = con.execute("SELECT id FROM misconceptions WHERE code=?", (code,)).fetchone()
        if not m:
            return
        con.execute(
            """INSERT INTO learner_misconceptions(user_id,misconception_id,status,strength,note)
               VALUES(?,?,'possible',?,?)
               ON CONFLICT(user_id,misconception_id) DO UPDATE SET
               status='possible', strength=MAX(strength,excluded.strength),
               note=excluded.note, last_seen_at=CURRENT_TIMESTAMP""",
            (user_id,m["id"],strength,note[:500]),
        )


def inspect_message_for_possible_misconceptions(user_id: int, message: str, context: dict[str, Any]) -> None:
    m = message.lower()
    if "mah" in m and ("energy" in m or "watt" in m or "wh" in m):
        flag_misconception(user_id,"MAH_IS_ENERGY",0.25,"Heuristic flag from coach message; requires confirmation.")
    if "watt" in m and "watt-hour" in m and any(x in m for x in ["same", "equal", "is a", "are a"]):
        flag_misconception(user_id,"ENERGY_POWER_CONFUSION",0.20,"Heuristic flag from coach message; requires confirmation.")
    if any(x in m for x in ["measured in the simulation", "measured by the simulation", "simulation measured"]):
        flag_misconception(user_id,"SIMULATION_IS_MEASUREMENT",0.30,"Heuristic flag from coach message; requires confirmation.")


def learner_snapshot(user_id: int, module_id: int | None = None) -> dict[str, Any]:
    with connection() as con:
        role_row = con.execute("SELECT role FROM users WHERE id=?", (user_id,)).fetchone()
    if not role_row or role_row["role"] != "learner":
        return {
            "concepts": [],
            "possible_misconceptions": [],
            "recent_runs": [],
            "recent_notebook": [],
            "recommended_next_concept": None,
            "model_note": "Educator/admin session: no learner model is inferred for this account."
        }
    ensure_learner_model(user_id)
    with connection() as con:
        if module_id:
            concepts = [dict(r) for r in con.execute(
                """SELECT c.code,c.title,c.description,lc.mastery,lc.exposure_count,lc.evidence_count,
                          lc.independence_mean,lc.last_evidence_at,mc.weight
                   FROM module_concepts mc JOIN concepts c ON c.id=mc.concept_id
                   JOIN learner_concepts lc ON lc.concept_id=c.id AND lc.user_id=?
                   WHERE mc.module_id=? ORDER BY mc.weight DESC,c.sort_order""",
                (user_id,module_id),
            )]
        else:
            concepts = [dict(r) for r in con.execute(
                """SELECT c.code,c.title,c.description,lc.mastery,lc.exposure_count,lc.evidence_count,
                          lc.independence_mean,lc.last_evidence_at,1.0 weight
                   FROM concepts c JOIN learner_concepts lc ON lc.concept_id=c.id AND lc.user_id=?
                   ORDER BY c.sort_order""",
                (user_id,),
            )]
        misconceptions = [dict(r) for r in con.execute(
            """SELECT m.code,m.title,m.description,lm.status,lm.strength,lm.note,lm.last_seen_at
               FROM learner_misconceptions lm JOIN misconceptions m ON m.id=lm.misconception_id
               WHERE lm.user_id=? AND lm.status!='resolved' ORDER BY lm.strength DESC,lm.last_seen_at DESC LIMIT 8""",
            (user_id,),
        )]
        recent_runs = [dict(r) for r in con.execute(
            "SELECT sim_type,title,created_at FROM lab_runs WHERE user_id=? ORDER BY id DESC LIMIT 5", (user_id,)
        )]
        recent_journal = [dict(r) for r in con.execute(
            "SELECT title,hypothesis,observation,interpretation,created_at FROM journal_entries WHERE user_id=? ORDER BY id DESC LIMIT 3", (user_id,)
        )]
    recommendation = recommend_next_concept(concepts)
    return {
        "concepts": concepts,
        "possible_misconceptions": misconceptions,
        "recent_runs": recent_runs,
        "recent_notebook": recent_journal,
        "recommended_next_concept": recommendation,
        "model_note": "Mastery values are conservative instructional estimates tied to recorded evidence, not psychological diagnoses."
    }


def recommend_next_concept(concepts: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not concepts:
        return None
    # Prefer an exposed-but-not-yet-secure concept, then a new concept.
    candidates = sorted(concepts, key=lambda c: (
        0 if int(c.get("exposure_count") or 0) > 0 else 1,
        float(c.get("mastery") or 0),
        -float(c.get("weight") or 1),
    ))
    c = candidates[0]
    return {"code":c["code"],"title":c["title"],"mastery":float(c.get("mastery") or 0)}
