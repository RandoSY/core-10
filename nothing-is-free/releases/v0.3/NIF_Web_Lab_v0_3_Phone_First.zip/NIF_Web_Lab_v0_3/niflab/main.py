from __future__ import annotations
import json, mimetypes, os, secrets
from pathlib import Path
from typing import Any
from fastapi import FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .auth import create_session, current_user, delete_session, hash_password, verify_password, require_role, require_csrf
from .config import BASE_DIR, COOKIE_SECURE, UPLOAD_DIR
from .db import connection, init_db
from .seed import seed
from .ai import ai_reply
from .learner_model import (
    ensure_learner_model, learner_snapshot, record_exposure, record_scored_evidence,
    inspect_message_for_possible_misconceptions,
)
from .teacher_soul import public_teacher_profile

app = FastAPI(title="NIF Web Laboratory", version="0.3.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

@app.on_event("startup")
def startup():
    init_db(); seed()

@app.get("/")
def root():
    return FileResponse(BASE_DIR / "static" / "index.html")

class RegisterBody(BaseModel):
    email: str
    display_name: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=10, max_length=200)

class LoginBody(BaseModel):
    email: str
    password: str

class ProgressBody(BaseModel):
    module_id: int
    status: str
    percent: float

class LabRunBody(BaseModel):
    module_id: int | None = None
    sim_type: str
    title: str
    inputs: dict[str, Any]
    outputs: dict[str, Any]
    elapsed_sim_s: float = 0

class JournalBody(BaseModel):
    module_id: int | None = None
    title: str
    hypothesis: str = ""
    observation: str = ""
    interpretation: str = ""
    next_question: str = ""

class CoachBody(BaseModel):
    message: str
    context: dict[str, Any] = {}
    upload_id: int | None = None
    module_id: int | None = None
    role: str = "socratic_coach"
    phase: str = "EXPLAIN"
    help_level: int | None = None

class InquiryCycleBody(BaseModel):
    id: int | None = None
    module_id: int | None = None
    title: str = "Inquiry cycle"
    prediction: str = ""
    commitment: str = ""
    experiment_summary: str = ""
    explanation: str = ""
    challenge_response: str = ""
    transfer_response: str = ""
    phase: str = "PREDICT"
    status: str = "active"

class AssessmentBody(BaseModel):
    learner_id: int
    concept_code: str
    score: float = Field(ge=0, le=1)
    independence: float = Field(ge=0, le=1)
    module_id: int | None = None
    notes: str = ""

@app.post("/api/auth/register")
def register(body: RegisterBody, response: Response):
    if "@" not in body.email:
        raise HTTPException(400,"Valid email required")
    ph,salt = hash_password(body.password)
    try:
        with connection() as con:
            cur = con.execute("INSERT INTO users(email,display_name,role,password_hash,password_salt) VALUES(?,?,?,?,?)",
                              (body.email.strip().lower(),body.display_name.strip(),"learner",ph,salt))
            uid = cur.lastrowid
            nif = con.execute("SELECT id FROM courses WHERE slug='nif'").fetchone()["id"]
            con.execute("INSERT INTO enrollments(user_id,course_id) VALUES(?,?)",(uid,nif))
    except Exception as e:
        if "UNIQUE" in str(e): raise HTTPException(409,"Email already registered")
        raise
    ensure_learner_model(uid)
    token,csrf,_ = create_session(uid)
    response.set_cookie("nif_session",token,httponly=True,samesite="lax",secure=COOKIE_SECURE,max_age=14*86400)
    return {"ok":True,"csrf":csrf}

@app.post("/api/auth/login")
def login(body: LoginBody, response: Response):
    with connection() as con:
        row = con.execute("SELECT * FROM users WHERE email=?",(body.email.strip().lower(),)).fetchone()
        if not row or not verify_password(body.password,row["password_hash"],row["password_salt"]):
            raise HTTPException(401,"Invalid credentials")
        con.execute("UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?",(row["id"],))
        uid = row["id"]
    if row["role"] == "learner": ensure_learner_model(uid)
    token,csrf,_ = create_session(uid)
    response.set_cookie("nif_session",token,httponly=True,samesite="lax",secure=COOKIE_SECURE,max_age=14*86400)
    return {"ok":True,"csrf":csrf}

@app.post("/api/auth/logout")
def logout(request: Request, response: Response):
    user = current_user(request, required=False)
    if user: require_csrf(request,user)
    delete_session(request.cookies.get("nif_session"))
    response.delete_cookie("nif_session")
    return {"ok":True}

@app.get("/api/me")
def me(request: Request):
    u = current_user(request, required=False)
    if not u: return {"authenticated":False}
    return {"authenticated":True,"id":u["id"],"email":u["email"],"display_name":u["display_name"],"role":u["role"],"csrf":u["csrf_token"]}

@app.get("/api/teacher-profile")
def teacher_profile(request: Request):
    current_user(request)
    return public_teacher_profile()

@app.get("/api/curriculum")
def curriculum(request: Request):
    current_user(request)
    with connection() as con:
        courses = [dict(r) for r in con.execute("SELECT id,slug,parent_id,code,title,description,sort_order FROM courses WHERE published=1 ORDER BY sort_order")]
        mods = [dict(r) for r in con.execute("SELECT id,course_id,slug,code,title,question,body,activity_type,sort_order FROM modules ORDER BY sort_order")]
    for c in courses: c["modules"]=[m for m in mods if m["course_id"]==c["id"]]
    return {"courses":courses}

@app.get("/api/dashboard")
def dashboard(request: Request):
    u=current_user(request)
    with connection() as con:
        total = con.execute("SELECT COUNT(*) n FROM modules m JOIN courses c ON c.id=m.course_id WHERE c.slug='nif'").fetchone()["n"]
        complete = con.execute("SELECT COUNT(*) n FROM progress WHERE user_id=? AND status='complete'",(u["id"],)).fetchone()["n"]
        runs = con.execute("SELECT COUNT(*) n FROM lab_runs WHERE user_id=?",(u["id"],)).fetchone()["n"]
        journal = con.execute("SELECT COUNT(*) n FROM journal_entries WHERE user_id=?",(u["id"],)).fetchone()["n"]
        recent = [dict(r) for r in con.execute("SELECT id,sim_type,title,elapsed_sim_s,created_at FROM lab_runs WHERE user_id=? ORDER BY id DESC LIMIT 8",(u["id"],))]
        cycles = con.execute("SELECT COUNT(*) n FROM inquiry_cycles WHERE user_id=? AND status='complete'",(u["id"],)).fetchone()["n"]
    learning = learner_snapshot(u["id"]) if u["role"] == "learner" else None
    return {"modules_total":total,"modules_complete":complete,"lab_runs":runs,"journal_entries":journal,"inquiry_cycles_complete":cycles,"recent_runs":recent,"learning":learning}

@app.get("/api/learning-model")
def learning_model(request: Request, module_id: int | None = None):
    u=current_user(request)
    if u["role"] != "learner":
        raise HTTPException(403,"Learner model is available from instructor-specific endpoints")
    return learner_snapshot(u["id"],module_id)

@app.post("/api/progress")
def progress(body:ProgressBody,request:Request):
    u=current_user(request); require_csrf(request,u)
    if body.status not in {"not_started","in_progress","complete"}: raise HTTPException(400,"Bad status")
    pct=max(0,min(100,body.percent))
    with connection() as con:
        con.execute("""INSERT INTO progress(user_id,module_id,status,percent) VALUES(?,?,?,?)
                       ON CONFLICT(user_id,module_id) DO UPDATE SET status=excluded.status,percent=excluded.percent,updated_at=CURRENT_TIMESTAMP""",
                    (u["id"],body.module_id,body.status,pct))
    return {"ok":True}

@app.post("/api/lab-runs")
def save_run(body:LabRunBody,request:Request):
    u=current_user(request); require_csrf(request,u)
    with connection() as con:
        cur=con.execute("INSERT INTO lab_runs(user_id,module_id,sim_type,title,inputs_json,outputs_json,elapsed_sim_s) VALUES(?,?,?,?,?,?,?)",
                    (u["id"],body.module_id,body.sim_type,body.title,json.dumps(body.inputs),json.dumps(body.outputs),body.elapsed_sim_s))
        run_id = cur.lastrowid
        con.execute("INSERT INTO events(user_id,event_type,payload_json) VALUES(?,?,?)",(u["id"],"lab_run",json.dumps({"id":run_id,"type":body.sim_type})))
    if u["role"] == "learner": record_exposure(u["id"],body.module_id,"lab_run",run_id,f"Simulation type: {body.sim_type}")
    return {"ok":True,"id":run_id}

@app.get("/api/lab-runs")
def list_runs(request:Request, limit:int=50):
    u=current_user(request)
    with connection() as con:
        rows=[dict(r) for r in con.execute("SELECT * FROM lab_runs WHERE user_id=? ORDER BY id DESC LIMIT ?",(u["id"],min(limit,200)))]
    for r in rows:
        r["inputs"]=json.loads(r.pop("inputs_json")); r["outputs"]=json.loads(r.pop("outputs_json"))
    return {"runs":rows}

@app.post("/api/journal")
def journal(body:JournalBody,request:Request):
    u=current_user(request); require_csrf(request,u)
    with connection() as con:
        cur=con.execute("INSERT INTO journal_entries(user_id,module_id,title,hypothesis,observation,interpretation,next_question) VALUES(?,?,?,?,?,?,?)",
                        (u["id"],body.module_id,body.title,body.hypothesis,body.observation,body.interpretation,body.next_question))
        jid = cur.lastrowid
    if u["role"] == "learner": record_exposure(u["id"],body.module_id,"journal",jid,"Learner created notebook evidence.")
    return {"ok":True,"id":jid}

@app.get("/api/journal")
def list_journal(request:Request):
    u=current_user(request)
    with connection() as con:
        rows=[dict(r) for r in con.execute("SELECT * FROM journal_entries WHERE user_id=? ORDER BY id DESC LIMIT 100",(u["id"],))]
    return {"entries":rows}

@app.post("/api/inquiry-cycles")
def save_inquiry_cycle(body: InquiryCycleBody, request: Request):
    u=current_user(request); require_csrf(request,u)
    phase = body.phase.upper()
    if phase not in {"PREDICT","COMMIT","EXPERIMENT","EXPLAIN","CHALLENGE","TRANSFER"}:
        raise HTTPException(400,"Bad inquiry phase")
    if body.status not in {"active","complete","abandoned"}: raise HTTPException(400,"Bad status")
    with connection() as con:
        if body.id:
            row = con.execute("SELECT id FROM inquiry_cycles WHERE id=? AND user_id=?",(body.id,u["id"])).fetchone()
            if not row: raise HTTPException(404)
            con.execute("""UPDATE inquiry_cycles SET module_id=?,title=?,prediction=?,commitment=?,experiment_summary=?,
                           explanation=?,challenge_response=?,transfer_response=?,phase=?,status=?,updated_at=CURRENT_TIMESTAMP
                           WHERE id=? AND user_id=?""",
                        (body.module_id,body.title,body.prediction,body.commitment,body.experiment_summary,body.explanation,
                         body.challenge_response,body.transfer_response,phase,body.status,body.id,u["id"]))
            cid=body.id
        else:
            cur=con.execute("""INSERT INTO inquiry_cycles(user_id,module_id,title,prediction,commitment,experiment_summary,
                               explanation,challenge_response,transfer_response,phase,status)
                               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                            (u["id"],body.module_id,body.title,body.prediction,body.commitment,body.experiment_summary,
                             body.explanation,body.challenge_response,body.transfer_response,phase,body.status))
            cid=cur.lastrowid
    return {"ok":True,"id":cid}

@app.get("/api/inquiry-cycles")
def list_inquiry_cycles(request: Request, limit: int = 50):
    u=current_user(request)
    with connection() as con:
        rows=[dict(r) for r in con.execute("SELECT * FROM inquiry_cycles WHERE user_id=? ORDER BY updated_at DESC LIMIT ?",(u["id"],min(limit,200)))]
    return {"cycles":rows}

@app.post("/api/uploads")
def upload(request:Request, file:UploadFile=File(...), module_id:int|None=Form(None), caption:str=Form("")):
    u=current_user(request); require_csrf(request,u)
    max_bytes=25*1024*1024
    suffix=Path(file.filename or "upload.bin").suffix.lower()[:10]
    stored=f"{u['id']}_{secrets.token_hex(12)}{suffix}"
    dst=UPLOAD_DIR/stored
    size=0
    with dst.open("wb") as out:
        while True:
            chunk=file.file.read(1024*1024)
            if not chunk: break
            size+=len(chunk)
            if size>max_bytes:
                out.close(); dst.unlink(missing_ok=True); raise HTTPException(413,"Upload exceeds 25 MB")
            out.write(chunk)
    mime=file.content_type or mimetypes.guess_type(file.filename or "")[0] or "application/octet-stream"
    if mime.startswith("image/"): kind="image"
    elif mime.startswith("audio/"): kind="audio"
    elif mime.startswith("video/"): kind="video"
    elif "pdf" in mime: kind="document"
    else: kind="data"
    with connection() as con:
        cur=con.execute("INSERT INTO uploads(user_id,module_id,original_name,stored_name,mime_type,size_bytes,media_kind,caption) VALUES(?,?,?,?,?,?,?,?)",
                        (u["id"],module_id,file.filename or stored,stored,mime,size,kind,caption[:500]))
    return {"ok":True,"id":cur.lastrowid,"kind":kind,"name":file.filename,"size":size}

@app.get("/api/uploads")
def uploads(request:Request):
    u=current_user(request)
    with connection() as con:
        rows=[dict(r) for r in con.execute("SELECT id,module_id,original_name,mime_type,size_bytes,media_kind,caption,created_at FROM uploads WHERE user_id=? ORDER BY id DESC LIMIT 100",(u["id"],))]
    return {"uploads":rows}

@app.get("/api/uploads/{upload_id}/content")
def upload_content(upload_id:int,request:Request):
    u=current_user(request)
    with connection() as con:
        row=con.execute("SELECT * FROM uploads WHERE id=? AND user_id=?",(upload_id,u["id"])).fetchone()
        if not row and u["role"] in {"instructor","admin"}:
            row=con.execute("SELECT * FROM uploads WHERE id=?",(upload_id,)).fetchone()
    if not row: raise HTTPException(404)
    return FileResponse(UPLOAD_DIR/row["stored_name"],media_type=row["mime_type"],filename=row["original_name"])

@app.post("/api/coach")
def coach(body:CoachBody,request:Request):
    u=current_user(request); require_csrf(request,u)
    module_id = body.module_id
    if module_id is None and isinstance(body.context, dict):
        module = body.context.get("module") or {}
        if isinstance(module, dict):
            module_id = module.get("id")
    if u["role"] == "learner": inspect_message_for_possible_misconceptions(u["id"],body.message,body.context)
    reply, used_help, mode = ai_reply(
        user_id=u["id"], module_id=module_id, message=body.message, context=body.context,
        role=body.role, phase=body.phase, help_level=body.help_level, upload_id=body.upload_id,
    )
    with connection() as con:
        con.execute("INSERT INTO events(user_id,event_type,payload_json) VALUES(?,?,?)",
                    (u["id"],"coach",json.dumps({"message":body.message[:500],"upload_id":body.upload_id,"role":body.role,"phase":body.phase,"help_level":used_help})))
        con.execute("""INSERT INTO coach_interactions(user_id,module_id,role,phase,help_level,user_message,assistant_reply,mode)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (u["id"],module_id,body.role,body.phase.upper(),used_help,body.message[:4000],reply[:12000],mode))
    return {"reply":reply,"mode":mode,"help_level":used_help,"phase":body.phase.upper(),"role":body.role}

@app.get("/api/instructor/roster")
def roster(request:Request):
    u=current_user(request); require_role(u,"instructor","admin")
    with connection() as con:
        rows=[dict(r) for r in con.execute("""SELECT u.id,u.display_name,u.email,
          COUNT(DISTINCT CASE WHEN p.status='complete' THEN p.module_id END) completed,
          COUNT(DISTINCT lr.id) lab_runs, COUNT(DISTINCT j.id) journal_entries,
          COALESCE(AVG(lc.mastery),0) mastery_avg,
          COUNT(DISTINCT CASE WHEN lm.status!='resolved' THEN lm.misconception_id END) misconception_flags
          FROM users u LEFT JOIN progress p ON p.user_id=u.id
          LEFT JOIN lab_runs lr ON lr.user_id=u.id LEFT JOIN journal_entries j ON j.user_id=u.id
          LEFT JOIN learner_concepts lc ON lc.user_id=u.id
          LEFT JOIN learner_misconceptions lm ON lm.user_id=u.id
          WHERE u.role='learner' GROUP BY u.id ORDER BY u.display_name""")]
    return {"learners":rows}

@app.get("/api/instructor/learner/{learner_id}/model")
def instructor_learner_model(learner_id:int, request:Request, module_id:int|None=None):
    u=current_user(request); require_role(u,"instructor","admin")
    with connection() as con:
        learner=con.execute("SELECT id,display_name,email FROM users WHERE id=? AND role='learner'",(learner_id,)).fetchone()
    if not learner: raise HTTPException(404)
    return {"learner":dict(learner),"model":learner_snapshot(learner_id,module_id)}

@app.post("/api/instructor/assessment")
def instructor_assessment(body:AssessmentBody, request:Request):
    u=current_user(request); require_role(u,"instructor","admin"); require_csrf(request,u)
    with connection() as con:
        learner=con.execute("SELECT id FROM users WHERE id=? AND role='learner'",(body.learner_id,)).fetchone()
    if not learner: raise HTTPException(404)
    record_scored_evidence(body.learner_id,body.concept_code,body.score,body.independence,
                           "instructor_assessment",None,body.module_id,body.notes)
    return {"ok":True,"model":learner_snapshot(body.learner_id,body.module_id)}

@app.get("/health")
def health(): return {"ok":True,"version":"0.3.0","teacher_soul":True,"phone_first":True}
