from __future__ import annotations
import json
from .db import connection
from .auth import hash_password
from .config import SEED_DEMO

COURSES = [
    ("core10","CORE10-0","CORE 10","Root architecture: Experience Before Equation; Need Before Technology; physical evidence remains authoritative.",None,0),
    ("kitchen","CORE10-1","Kitchen Inquiry Lab","Household phenomena become quantitative inquiry.","core10",1),
    ("one-cup","CORE10-2","One Cup Chemistry","One-vessel chemistry: solutions, heat, ions, crystals, electrochemistry and premise testing.","core10",2),
    ("nif","CORE10-3","NOTHING IS FREE","Energy, flux, storage, work, automation, efficiency, cost and electric transportation.","core10",3),
]

NIF_MODULES = [
    ("phone-charge","CORE10-3.00","Charge Your Phone","You charge this thing every day. How much energy does it actually take?","Begin with the familiar: follow energy from wall outlet → charger → cable → phone electronics → battery. Observe voltage, current, power, watt-hours, charging taper, losses and cost before formalizing the equations.","phone",0),
    ("ledger","CORE10-3.01","Follow the Energy Ledger","Where did the phone-charging energy come from and where did it go?","Generalize the phone experience into source → conversion → storage → useful work → loss → cost.","ledger",1),
    ("power-time","CORE10-3.02","Energy, Power, and Time","Why are watts not watt-hours?","Return to the phone charger readings to name and calculate P=VI, E=Pt, Wh, J and operating time.","meter",2),
    ("flux","CORE10-3.03","Flux and Irradiance","If the wall is not the source, how much power arrives from light?","Explore G=P/A, projected area, source distance and orientation as preparation for solar charging.","solar",3),
    ("flashlight-panel","CORE10-3.04","Flashlight to Solar Panel","Can light make enough electricity to register on the same kind of energy ledger?","Measure a weak but visible photovoltaic response and account for the inefficient conversion chain.","solar",4),
    ("sunlight","CORE10-3.05","Catch the Sun","Can sunlight provide useful charging power?","Vary irradiance, angle, temperature and shading; accumulate Wh and compare with the phone-charging baseline.","solar",5),
    ("charge","CORE10-3.06","Store the Sun","How much solar energy reaches rechargeable cells?","Model NiMH charging, conversion losses, state of charge and charge termination, then compare with the phone battery path.","battery",6),
    ("wall-vs-sun","CORE10-3.07","Wall versus Sun","Does changing the source change the ledger?","Hold the downstream storage problem constant and compare wall and solar input.","battery",7),
    ("robot","CORE10-3.08","Battery to Motion","What if stored energy does something visible instead of merely filling a phone battery?","Run the 2WD robot; measure runtime, distance and Wh per meter.","robot",8),
    ("software-energy","CORE10-3.09","Software Costs Energy","Can better decisions save battery energy?","Compare random obstacle avoidance to Energy Explorer using identical virtual hardware.","robot",9),
    ("hill","CORE10-3.10","Climb the Hill","How much useful mechanical work did the battery buy?","Use mgh and compare useful mechanical energy with electrical energy consumed.","robot",10),
    ("microwave","CORE10-3.11","Microwave Water Heating","How does a familiar high-power appliance change the scale?","Compare electrical input with Q=mcΔT and identify losses; contrast hundreds of watt-hours with a phone charge of only a few watt-hours.","thermal",11),
    ("bill","CORE10-3.12","From Phone Charge to Electric Bill","If a phone charge costs almost nothing, why is the household bill substantial?","Read a utility bill; distinguish marginal and all-in rates; convert Wh and kWh to dollars.","bill",12),
    ("ev-scale","CORE10-3.13","From Phone to $10 Robot to EV","What survives as stored-energy systems become much larger?","Compare Wh per task, Wh/m, Wh/mi, kWh/100mi and operating cost without assuming geometric similarity.","robot",13),
    ("capstone","CORE10-3.14","2050 Energy Capstone","Can you account for energy regardless of the technology?","Start from phone charging and design, simulate, test and defend a complete energy system using evidence from the full ledger.","capstone",14),
]

CONCEPTS = [
    ("measurement","Measurement","Distinguish a reading from a claim and identify the instrument that produced it.",[],0),
    ("units","Units","Carry units through measurements and calculations and use them to detect bad reasoning.",["measurement"],1),
    ("provenance","Evidence Provenance","Keep MEASURED, SIMULATED, CALCULATED, and AI_INFERENCE separate.",["measurement"],2),
    ("experimental_controls","Experimental Controls","Choose controls required by the hypothesis rather than trying to 'control everything'.",["measurement"],3),
    ("uncertainty","Uncertainty","Recognize instrument resolution, noise, variability, and limits on inference.",["measurement","units"],4),
    ("model_limits","Model Limits","Treat models as useful approximations and distinguish fit from mechanism.",["provenance","uncertainty"],5),
    ("energy_ledger","Energy Ledger","Account for source, conversion, storage, useful work, losses, and cost.",["measurement","units"],6),
    ("energy_vs_power","Energy vs Power","Distinguish energy amounts from rates of energy transfer.",["units","energy_ledger"],7),
    ("electrical_power","Electrical Power","Use P = VI and interpret volts, amps, and watts physically.",["energy_vs_power"],8),
    ("energy_time","Energy and Time","Use E = Pt and reason about operating time from stored energy and power demand.",["energy_vs_power"],9),
    ("wh_j","Wh and Joules","Convert consistently between joules, watt-hours, and kilowatt-hours.",["energy_time"],10),
    ("irradiance","Flux and Irradiance","Reason about incident power per unit area.",["energy_vs_power"],11),
    ("projected_area","Projected Area","Relate orientation and effective area to intercepted radiant power.",["irradiance"],12),
    ("solar_conversion","Solar Conversion","Track radiant input through photovoltaic conversion to electrical output.",["irradiance","electrical_power"],13),
    ("storage","Energy Storage","Treat a battery as stored energy with finite capacity and nonideal behavior.",["wh_j"],14),
    ("battery_energy","Battery Energy","Use voltage and amp-hours together to estimate stored watt-hours.",["storage","electrical_power"],15),
    ("charging_efficiency","Charging Efficiency","Distinguish charger input energy from energy ultimately stored in cells.",["battery_energy"],16),
    ("efficiency","Efficiency","Compare useful output with input while preserving the full loss ledger.",["energy_ledger","wh_j"],17),
    ("robot_energy","Energy to Motion","Relate battery energy, motor power, runtime, distance, and motion metrics.",["battery_energy","efficiency"],18),
    ("software_energy","Software and Energy","Recognize that control decisions alter physical energy expenditure.",["robot_energy"],19),
    ("useful_work","Useful Work","Relate electrical input to mechanical work such as mgh.",["efficiency","energy_time"],20),
    ("thermal_energy","Thermal Energy","Use Q = mcΔT as an estimate of useful thermal energy while tracking losses.",["energy_ledger","energy_time"],21),
    ("utility_cost","Energy Cost","Translate energy use into kWh and dollars, separating marginal from all-in cost.",["wh_j"],22),
    ("scale_transfer","Scale Transfer","Carry governing relationships to a new scale without assuming geometric or efficiency similarity.",["robot_energy","utility_cost","model_limits"],23),
]

MODULE_CONCEPTS = {
    "phone-charge": ["measurement","provenance","energy_ledger","energy_vs_power","electrical_power","energy_time","wh_j","storage","charging_efficiency","utility_cost"],
    "ledger": ["measurement","units","provenance","energy_ledger"],
    "power-time": ["energy_vs_power","electrical_power","energy_time","wh_j","units"],
    "flux": ["irradiance","projected_area","units","model_limits"],
    "flashlight-panel": ["irradiance","solar_conversion","efficiency","provenance"],
    "sunlight": ["solar_conversion","irradiance","projected_area","uncertainty","measurement"],
    "charge": ["storage","battery_energy","charging_efficiency","efficiency"],
    "wall-vs-sun": ["experimental_controls","charging_efficiency","energy_ledger","provenance"],
    "robot": ["robot_energy","battery_energy","energy_time","measurement"],
    "software-energy": ["software_energy","robot_energy","experimental_controls","efficiency"],
    "hill": ["useful_work","efficiency","robot_energy","units"],
    "microwave": ["thermal_energy","efficiency","energy_ledger","experimental_controls"],
    "bill": ["utility_cost","wh_j","energy_ledger"],
    "ev-scale": ["scale_transfer","robot_energy","utility_cost","model_limits"],
    "capstone": ["energy_ledger","experimental_controls","provenance","model_limits","scale_transfer","efficiency"],
}

MISCONCEPTIONS = [
    ("ENERGY_POWER_CONFUSION","Energy and power are interchangeable","Treats watts as energy or watt-hours as a power rate.","energy_vs_power","Require units and ask what accumulates as time passes."),
    ("MAH_IS_ENERGY","mAh alone is energy","Compares stored energy using amp-hours without voltage.","battery_energy","Ask for V × Ah and compare equal-Ah packs at different voltages."),
    ("RATED_EQUALS_ACTUAL","Rated power equals operating power","Uses a nameplate rating as if it were a measurement.","measurement","Ask which number came from a label and which from an instrument."),
    ("EFFICIENCY_100","Conversions are lossless","Assumes input energy equals useful output.","efficiency","Build the complete input/output/loss ledger."),
    ("SIMULATION_IS_MEASUREMENT","Simulation output is a physical measurement","Calls simulated output measured evidence.","provenance","Relabel as SIMULATED and ask what physical test could validate it."),
    ("CONTROL_ALL_VARIABLES","A fair test controls everything","Uses a generic controls slogan without tying variables to the hypothesis.","experimental_controls","Ask which variable creates an alternate explanation for this question."),
    ("FIT_PROVES_MECHANISM","A good fit proves the mechanism","Treats mathematical agreement as causal proof.","model_limits","Ask for another mechanism that could generate a similar curve."),
    ("MISSING_ENERGY_DISAPPEARED","Unaccounted energy vanished","Treats the residual as disappearance rather than conversion/transfer.","energy_ledger","Require plausible thermal, mechanical, electrical, acoustic, or radiative destinations."),
]


def seed():
    with connection() as con:
        existing = {r["slug"]: r["id"] for r in con.execute("SELECT id,slug FROM courses")}
        for slug,code,title,desc,parent_slug,sort in COURSES:
            parent_id = existing.get(parent_slug) if parent_slug else None
            con.execute("""INSERT INTO courses(slug,parent_id,code,title,description,sort_order) VALUES(?,?,?,?,?,?)
                         ON CONFLICT(slug) DO UPDATE SET parent_id=excluded.parent_id,code=excluded.code,title=excluded.title,
                         description=excluded.description,sort_order=excluded.sort_order""",
                        (slug,parent_id,code,title,desc,sort))
            existing[slug] = con.execute("SELECT id FROM courses WHERE slug=?",(slug,)).fetchone()["id"]
        nif_id = existing["nif"]
        module_ids = {}
        for slug,code,title,q,body,atype,sort in NIF_MODULES:
            con.execute("""INSERT INTO modules(course_id,slug,code,title,question,body,activity_type,sort_order) VALUES(?,?,?,?,?,?,?,?)
                         ON CONFLICT(course_id,slug) DO UPDATE SET code=excluded.code,title=excluded.title,question=excluded.question,
                         body=excluded.body,activity_type=excluded.activity_type,sort_order=excluded.sort_order""",
                        (nif_id,slug,code,title,q,body,atype,sort))
            module_ids[slug] = con.execute("SELECT id FROM modules WHERE course_id=? AND slug=?",(nif_id,slug)).fetchone()["id"]

        for code,title,desc,prereqs,sort in CONCEPTS:
            con.execute("INSERT OR IGNORE INTO concepts(code,title,description,prerequisites_json,sort_order) VALUES(?,?,?,?,?)",
                        (code,title,desc,json.dumps(prereqs),sort))
        concept_ids = {r["code"]:r["id"] for r in con.execute("SELECT id,code FROM concepts")}

        for module_slug,codes in MODULE_CONCEPTS.items():
            mid = module_ids[module_slug]
            for rank,code in enumerate(codes):
                weight = max(0.55, 1.0 - rank*0.1)
                con.execute("INSERT OR IGNORE INTO module_concepts(module_id,concept_id,weight) VALUES(?,?,?)",
                            (mid,concept_ids[code],weight))

        for code,title,desc,concept_code,teacher_move in MISCONCEPTIONS:
            con.execute("INSERT OR IGNORE INTO misconceptions(code,title,description,concept_code,teacher_move) VALUES(?,?,?,?,?)",
                        (code,title,desc,concept_code,teacher_move))

        if SEED_DEMO:
            for email,name,role,pw in [
                ("student@nif.local","Demo Student","learner","Learn2050!"),
                ("teacher@nif.local","Demo Teacher","instructor","Teach2050!"),
            ]:
                if not con.execute("SELECT 1 FROM users WHERE email=?",(email,)).fetchone():
                    ph,salt = hash_password(pw)
                    con.execute("INSERT INTO users(email,display_name,role,password_hash,password_salt) VALUES(?,?,?,?,?)",
                                (email,name,role,ph,salt))
            student_id = con.execute("SELECT id FROM users WHERE email='student@nif.local'").fetchone()["id"]
            con.execute("INSERT OR IGNORE INTO enrollments(user_id,course_id) VALUES(?,?)",(student_id,nif_id))

        # Every existing learner gets an explicit concept-state row. This is auditable state, not model memory.
        learners = con.execute("SELECT id FROM users WHERE role='learner'").fetchall()
        for learner in learners:
            for cid in concept_ids.values():
                con.execute("INSERT OR IGNORE INTO learner_concepts(user_id,concept_id) VALUES(?,?)",(learner["id"],cid))
