from __future__ import annotations
import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from .config import TEACHER_SOUL_DIR

@lru_cache(maxsize=1)
def load_teacher_soul() -> dict[str, Any]:
    profile = json.loads((TEACHER_SOUL_DIR / "teacher_profile.json").read_text(encoding="utf-8"))
    patterns = json.loads((TEACHER_SOUL_DIR / "diagnostic_patterns.json").read_text(encoding="utf-8"))
    constitution = (TEACHER_SOUL_DIR / "TEACHER_CONSTITUTION.md").read_text(encoding="utf-8")
    exemplars = (TEACHER_SOUL_DIR / "exemplar_dialogues.md").read_text(encoding="utf-8")
    return {
        "profile": profile,
        "patterns": patterns,
        "constitution": constitution,
        "exemplars": exemplars,
    }

def bounded_help_level(phase: str, requested: int | None) -> int:
    soul = load_teacher_soul()["profile"]
    phase = (phase or "EXPLAIN").upper()
    cap = int(soul.get("phase_help_caps", {}).get(phase, 5))
    if requested is None:
        defaults = {"PREDICT": 1, "COMMIT": 2, "EXPERIMENT": 2, "EXPLAIN": 3, "CHALLENGE": 3, "TRANSFER": 3}
        requested = defaults.get(phase, 3)
    return max(0, min(int(requested), cap, 6))

def build_teacher_prompt(*, role: str, phase: str, help_level: int, learner_snapshot: dict[str, Any], lab_context: dict[str, Any]) -> str:
    soul = load_teacher_soul()
    profile = soul["profile"]
    role_key = role if role in profile.get("roles", {}) else profile.get("default_role", "socratic_coach")
    role_text = profile.get("roles", {}).get(role_key, "Teach by evidence and inquiry.")
    help_text = profile.get("help_levels", {}).get(str(help_level), "use restrained help")
    provenance = ", ".join(profile.get("provenance_labels", []))

    snapshot_json = json.dumps(learner_snapshot, ensure_ascii=False)[:12000]
    context_json = json.dumps(lab_context, ensure_ascii=False)[:10000]

    return f"""You are the CORE 10 Teacher runtime inside the NOTHING IS FREE Web Laboratory.

ROLE: {role_key}
ROLE PURPOSE: {role_text}
INQUIRY PHASE: {phase}
HELP LEVEL: {help_level} — {help_text}

Non-negotiable rule: preserve evidence provenance. Use these labels when useful: {provenance}.
Never invent a measurement, lab result, learner history, or mastery claim.
During PREDICT or COMMIT, do not reveal the target result if the learner can reasonably discover it.
When a premise is defective, expose the defect instead of silently repairing it.
If a learner is asking about physical work and the procedure is unsafe, safety overrides productive struggle.

LEARNER SNAPSHOT (database evidence, not a personality diagnosis):
{snapshot_json}

CURRENT LAB/MODULE CONTEXT:
{context_json}

TEACHER CONSTITUTION:
{soul['constitution'][:14000]}

CALIBRATION EXAMPLES:
{soul['exemplars'][:7000]}

Answer in the voice implied by the constitution. Be concrete. Usually ask for or point to evidence before giving an explanation. Use mathematics when it clarifies the physical mechanism. Keep the next move actionable.
"""

def public_teacher_profile() -> dict[str, Any]:
    soul = load_teacher_soul()
    p = soul["profile"]
    return {
        "name": p.get("name"),
        "version": p.get("version"),
        "mission": p.get("mission"),
        "mottos": p.get("mottos", []),
        "roles": p.get("roles", {}),
        "inquiry_phases": p.get("inquiry_phases", []),
        "help_levels": p.get("help_levels", {}),
        "provenance_labels": p.get("provenance_labels", []),
    }
