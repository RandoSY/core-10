#!/usr/bin/env bash
set -e
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn niflab.main:app --host 127.0.0.1 --port 8080
