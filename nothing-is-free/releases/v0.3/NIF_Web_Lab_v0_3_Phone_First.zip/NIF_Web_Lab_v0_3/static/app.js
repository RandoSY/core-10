window.NIFApp = (()=>{
let me=null, csrf='', curriculum=null, currentModule=null, coachContext={}, recorder=null, recordChunks=[];
let teacherProfile=null, learningModel=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

async function api(url,opts={}){
  opts.headers=opts.headers||{};
  if(opts.body&&!(opts.body instanceof FormData)) opts.headers['Content-Type']='application/json';
  if(csrf&&['POST','PUT','PATCH','DELETE'].includes((opts.method||'GET').toUpperCase())) opts.headers['X-CSRF-Token']=csrf;
  const r=await fetch(url,opts);
  if(!r.ok){let m='Request failed';try{m=(await r.json()).detail||m}catch{}throw new Error(m)}
  return r.json();
}
function toast(msg){const t=$('#toast');t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2600)}
function setCoachContext(c){coachContext=c||{}}
function showAuth(){ $('#authView').classList.remove('hidden');$('#appView').classList.add('hidden') }
function showApp(){
  $('#authView').classList.add('hidden');$('#appView').classList.remove('hidden');
  $('#userBadge').textContent=`${me.display_name} · ${me.role}`;
  if(['instructor','admin'].includes(me.role)) $$('.instructor-only').forEach(e=>e.classList.remove('hidden'));
}
async function init(){
  try{
    const m=await api('/api/me');if(!m.authenticated){showAuth();return}
    me=m;csrf=m.csrf;showApp();
    const tasks=[loadCurriculum(),loadDashboard(),loadJournal(),loadMedia(),loadTeacherProfile(),loadCycles()];
    if(me.role==='learner') tasks.push(loadLearningModel());
    await Promise.all(tasks);
    NIFSim.render('phone',$('#simHost'));
    if(['instructor','admin'].includes(me.role)) loadRoster();
  }catch(e){console.error(e);showAuth()}
}

async function loadCurriculum(){
  curriculum=await api('/api/curriculum');
  const nif=curriculum.courses.find(c=>c.slug==='nif');const grid=$('#moduleGrid');grid.innerHTML='';
  nif.modules.forEach(m=>{
    const card=document.createElement('article');card.className='module-card'+(m.slug==='phone-charge'?' focus-module':'');
    card.innerHTML=`<span class="code">${m.code}</span><h3>${escapeHtml(m.title)}</h3><p>${escapeHtml(m.question)}</p><span class="type">${escapeHtml(m.activity_type)}</span>`;
    card.onclick=()=>openModule(m);grid.appendChild(card)
  });
  currentModule=nif.modules[0];renderNextModule();
}
function renderNextModule(){
  if(!currentModule)return;
  $('#nextModule').innerHTML=`<span class="type">${currentModule.code}</span><h3>${escapeHtml(currentModule.title)}</h3><p><strong>${escapeHtml(currentModule.question)}</strong></p><p class="muted">${escapeHtml(currentModule.body)}</p>`
}
function openModule(m){
  currentModule=m;renderNextModule();switchView('lab');
  const simMap={phone:'phone',ledger:'ledger',meter:'phone',solar:'solar',battery:'battery',robot:'robot',thermal:'thermal',bill:'bill',capstone:'ledger'};
  const name=simMap[m.activity_type]||'ledger';
  $$('.lab-tab').forEach(b=>b.classList.toggle('active',b.dataset.sim===name));
  NIFSim.render(name,$('#simHost'));setCoachContext({module:m});markProgress(m.id,'in_progress',10);
  if(me.role==='learner') loadLearningModel(m.id);
}
async function loadDashboard(){
  const d=await api('/api/dashboard');
  const next=d.learning?.recommended_next_concept?.title||'Evidence first';
  $('#kpiGrid').innerHTML=[
    ['Modules complete',`${d.modules_complete}/${d.modules_total}`],
    ['Saved lab runs',d.lab_runs],
    ['Inquiry cycles',d.inquiry_cycles_complete],
    ['Next concept',next]
  ].map(x=>`<div class="kpi"><b>${escapeHtml(x[1])}</b><small>${escapeHtml(x[0])}</small></div>`).join('');
  $('#recentRuns').innerHTML=d.recent_runs.length?d.recent_runs.map(r=>`<div class="list-row"><span>${escapeHtml(r.title)}<small> · ${escapeHtml(r.sim_type)}</small></span><small>${escapeHtml(r.created_at)}</small></div>`).join(''):'<p class="muted">No saved runs yet.</p>'
}
async function saveRun(run){
  if(currentModule)run.module_id=currentModule.id;
  const r=await api('/api/lab-runs',{method:'POST',body:JSON.stringify(run)});toast('Lab run saved to your account');
  if(currentModule)await markProgress(currentModule.id,'in_progress',50);loadDashboard();if(me.role==='learner')loadLearningModel(currentModule?.id);return r
}
async function markProgress(module_id,status,percent){try{await api('/api/progress',{method:'POST',body:JSON.stringify({module_id,status,percent})})}catch(e){console.warn(e)}}
function switchView(name){
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${name}`));
  $$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===name));
  if(name==='notebook')loadJournal(); if(name==='media')loadMedia(); if(name==='instructor')loadRoster();
  if(name==='trajectory'&&me.role==='learner')loadLearningModel(currentModule?.id); if(name==='inquiry')loadCycles();
}

async function loadTeacherProfile(){
  teacherProfile=await api('/api/teacher-profile');
  renderTeacherSoul();
}
function renderTeacherSoul(){
  const host=$('#teacherSoulCard');if(!host||!teacherProfile)return;
  const mottos=(teacherProfile.mottos||[]).slice(0,5).map(x=>`<span class="soul-chip">${escapeHtml(x)}</span>`).join('');
  host.innerHTML=`<p><strong>${escapeHtml(teacherProfile.mission||'')}</strong></p><div class="soul-chips">${mottos}</div><p class="muted">The AI model may change. These rules, phases, roles, and help limits remain inspectable source files.</p>`;
}

async function loadLearningModel(moduleId=null){
  if(!me||me.role!=='learner')return;
  const q=moduleId?`?module_id=${moduleId}`:''; learningModel=await api('/api/learning-model'+q); renderLearningModel();
}
function renderLearningModel(){
  if(!learningModel)return;
  const next=learningModel.recommended_next_concept;
  $('#trajectoryNext').textContent=next?`Next: ${next.title}`:'No recommendation yet';
  const concepts=learningModel.concepts||[];
  $('#conceptList').innerHTML=concepts.length?concepts.map(c=>{
    const pct=Math.round((c.mastery||0)*100);const exp=c.exposure_count||0;const ev=c.evidence_count||0;const ind=Math.round((c.independence_mean||0)*100);
    return `<div class="concept-row"><div class="concept-top"><strong>${escapeHtml(c.title)}</strong><span>${pct}% evidence</span></div><div class="mastery-bar"><i style="width:${pct}%"></i></div><small>${escapeHtml(c.description)} · exposures ${exp} · scored evidence ${ev}${ev?` · independence ${ind}%`:''}</small></div>`
  }).join(''):'<p class="muted">No concept model available.</p>';
  const ms=learningModel.possible_misconceptions||[];
  $('#misconceptionList').innerHTML=ms.length?ms.map(x=>`<div class="list-row"><div><strong>${escapeHtml(x.title)}</strong><small style="display:block">${escapeHtml(x.description)}</small></div><span class="flag-pill">${escapeHtml(x.status)}</span></div>`).join(''):'<p class="muted">No misconception flags. Absence of a flag is not proof of mastery.</p>';
}

async function loadJournal(){
  if(!me)return;const d=await api('/api/journal');
  $('#journalList').innerHTML=d.entries.length?d.entries.map(e=>`<div class="list-row"><div><strong>${escapeHtml(e.title)}</strong><small style="display:block">${escapeHtml(e.observation||e.hypothesis||'')}</small></div><small>${escapeHtml(e.created_at)}</small></div>`).join(''):'<p class="muted">No entries yet.</p>'
}
async function loadMedia(){
  if(!me)return;const d=await api('/api/uploads');const sel=$('#coachAttachment');
  sel.innerHTML='<option value="">No image attached</option>'+d.uploads.filter(x=>x.media_kind==='image').map(x=>`<option value="${x.id}">${escapeHtml(x.original_name)}</option>`).join('');
  $('#mediaList').innerHTML=d.uploads.length?d.uploads.map(x=>`<a class="media-card" href="/api/uploads/${x.id}/content" target="_blank">${x.media_kind==='image'?`<img src="/api/uploads/${x.id}/content" alt="">`:`<div class="file-icon">${x.media_kind==='audio'?'♫':x.media_kind==='video'?'▶':'▤'}</div>`}<strong>${escapeHtml(x.original_name)}</strong><small>${escapeHtml(x.media_kind)} · ${(x.size_bytes/1024).toFixed(0)} KB</small></a>`).join(''):'<p class="muted">No uploaded evidence yet.</p>'
}

async function loadCycles(){
  if(!me)return;const d=await api('/api/inquiry-cycles');
  $('#cycleList').innerHTML=d.cycles.length?d.cycles.map(c=>`<button class="cycle-row" data-cycle-id="${c.id}"><strong>${escapeHtml(c.title)}</strong><span>${escapeHtml(c.phase)} · ${escapeHtml(c.status)}</span><small>${escapeHtml(c.updated_at)}</small></button>`).join(''):'<p class="muted">No inquiry cycle saved yet. Start with a prediction.</p>';
  $$('#cycleList [data-cycle-id]').forEach(b=>b.onclick=()=>{const c=d.cycles.find(x=>x.id===+b.dataset.cycleId);if(c)fillCycle(c)})
}
function fillCycle(c){
  $('#cycleId').value=c.id||'';$('#cycleTitle').value=c.title||'';$('#cyclePrediction').value=c.prediction||'';$('#cycleCommitment').value=c.commitment||'';$('#cycleExperiment').value=c.experiment_summary||'';$('#cycleExplanation').value=c.explanation||'';$('#cycleChallenge').value=c.challenge_response||'';$('#cycleTransfer').value=c.transfer_response||'';$('#cyclePhase').value=c.phase||'PREDICT';
  $('#coachPhase').value=c.phase||'PREDICT';
}
async function saveCycle(e){
  e.preventDefault();
  const body={id:$('#cycleId').value?+$('#cycleId').value:null,module_id:currentModule?.id||null,title:$('#cycleTitle').value,prediction:$('#cyclePrediction').value,commitment:$('#cycleCommitment').value,experiment_summary:$('#cycleExperiment').value,explanation:$('#cycleExplanation').value,challenge_response:$('#cycleChallenge').value,transfer_response:$('#cycleTransfer').value,phase:$('#cyclePhase').value,status:$('#cyclePhase').value==='TRANSFER'&&$('#cycleTransfer').value.trim()?'complete':'active'};
  const d=await api('/api/inquiry-cycles',{method:'POST',body:JSON.stringify(body)});$('#cycleId').value=d.id;$('#coachPhase').value=body.phase;toast('Inquiry cycle saved');loadCycles();loadDashboard();
}

async function loadRoster(){
  if(!me||!['instructor','admin'].includes(me.role))return;const d=await api('/api/instructor/roster');
  $('#rosterBody').innerHTML=d.learners.map(x=>`<tr data-learner-id="${x.id}"><td>${escapeHtml(x.display_name)}</td><td>${escapeHtml(x.email)}</td><td>${x.completed}</td><td>${x.lab_runs}</td><td>${x.journal_entries}</td><td>${Math.round((x.mastery_avg||0)*100)}%</td><td>${x.misconception_flags||0}</td></tr>`).join('');
  $$('#rosterBody tr[data-learner-id]').forEach(tr=>tr.onclick=()=>loadInstructorLearner(+tr.dataset.learnerId));
}
async function loadInstructorLearner(id){
  const d=await api(`/api/instructor/learner/${id}/model`);const m=d.model;const concepts=(m.concepts||[]).slice().sort((a,b)=>(a.mastery||0)-(b.mastery||0)).slice(0,8);
  $('#instructorDetail').innerHTML=`<div class="panel-head"><div><h3>${escapeHtml(d.learner.display_name)}</h3><p class="muted">Evidence-based learner model</p></div><span class="type">Next: ${escapeHtml(m.recommended_next_concept?.title||'collect evidence')}</span></div><div class="concept-list">${concepts.map(c=>`<div class="concept-row"><div class="concept-top"><strong>${escapeHtml(c.title)}</strong><span>${Math.round((c.mastery||0)*100)}%</span></div><div class="mastery-bar"><i style="width:${Math.round((c.mastery||0)*100)}%"></i></div></div>`).join('')}</div><hr><h4>Possible misconception flags</h4>${(m.possible_misconceptions||[]).length?(m.possible_misconceptions||[]).map(x=>`<p><strong>${escapeHtml(x.title)}</strong> — ${escapeHtml(x.description)}</p>`).join(''):'<p class="muted">None currently flagged.</p>'}`;
}

function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}

function bind(){
  const landingStart=$('#landingStart'); if(landingStart) landingStart.onclick=()=>{ const email=$('#loginEmail'); email?.focus(); document.querySelector('.landing-login')?.scrollIntoView({behavior:'smooth',block:'center'}); };
  $$('[data-auth-open]').forEach(b=>b.onclick=()=>{ const target=b.dataset.authOpen; const tab=$(`[data-auth-tab="${target}"]`); tab?.click(); document.querySelector('.landing-login')?.scrollIntoView({behavior:'smooth',block:'center'}); });
  $$('[data-auth-tab]').forEach(b=>b.onclick=()=>{$$('[data-auth-tab]').forEach(x=>x.classList.toggle('active',x===b));$('#loginForm').classList.toggle('hidden',b.dataset.authTab!=='login');$('#registerForm').classList.toggle('hidden',b.dataset.authTab!=='register')});
  $('#loginForm').onsubmit=async e=>{e.preventDefault();try{const d=await api('/api/auth/login',{method:'POST',body:JSON.stringify({email:$('#loginEmail').value,password:$('#loginPassword').value})});csrf=d.csrf;init()}catch(err){toast(err.message)}};
  $('#registerForm').onsubmit=async e=>{e.preventDefault();try{const d=await api('/api/auth/register',{method:'POST',body:JSON.stringify({email:$('#regEmail').value,display_name:$('#regName').value,password:$('#regPassword').value})});csrf=d.csrf;init()}catch(err){toast(err.message)}};
  $('#logoutBtn').onclick=async()=>{try{await api('/api/auth/logout',{method:'POST'})}finally{location.reload()}};
  $$('.nav').forEach(n=>n.onclick=()=>switchView(n.dataset.view));
  $$('.lab-tab').forEach(b=>b.onclick=()=>{$$('.lab-tab').forEach(x=>x.classList.toggle('active',x===b));NIFSim.render(b.dataset.sim,$('#simHost'))});
  $('#continueBtn').onclick=()=>currentModule&&openModule(currentModule);
  $('#journalForm').onsubmit=async e=>{e.preventDefault();await api('/api/journal',{method:'POST',body:JSON.stringify({module_id:currentModule?.id||null,title:$('#jTitle').value,hypothesis:$('#jHypothesis').value,observation:$('#jObservation').value,interpretation:$('#jInterpretation').value,next_question:$('#jNext').value})});toast('Evidence entry saved');loadJournal();if(me.role==='learner')loadLearningModel(currentModule?.id)};
  $('#newJournalBtn').onclick=()=>{$('#journalForm').reset();$('#jTitle').value=currentModule?currentModule.title:'NIF inquiry'};
  $('#cycleForm').onsubmit=saveCycle;
  $('#cyclePhase').onchange=()=>{$('#coachPhase').value=$('#cyclePhase').value};
  $('#uploadForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData();fd.append('file',$('#uploadFile').files[0]);fd.append('caption',$('#uploadCaption').value);if(currentModule)fd.append('module_id',currentModule.id);await api('/api/uploads',{method:'POST',body:fd});toast('Evidence uploaded');e.target.reset();loadMedia()};
  $('#coachSend').onclick=sendCoach;$('#coachText').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey))sendCoach()});
  $('#coachHelp').oninput=()=>{$('#coachHelpOut').value=$('#coachHelp').value;$('#coachHelpOut').textContent=$('#coachHelp').value};
  $('#speakBtn').onclick=()=>{const text=currentModule?`${currentModule.title}. ${currentModule.question}. ${currentModule.body}`:'Nothing Is Free. Learn to account for energy in any technology.';speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text))};
  setupRecorder();
}
async function sendCoach(){
  const text=$('#coachText').value.trim();if(!text)return;const thread=$('#coachThread');
  thread.insertAdjacentHTML('beforeend',`<div class="coach-msg user">${escapeHtml(text)}</div>`);$('#coachText').value='';thread.scrollTop=thread.scrollHeight;
  try{
    const body={message:text,context:{...coachContext,module:currentModule},module_id:currentModule?.id||null,upload_id:$('#coachAttachment').value?+$('#coachAttachment').value:null,role:$('#coachRole').value,phase:$('#coachPhase').value,help_level:+$('#coachHelp').value};
    const d=await api('/api/coach',{method:'POST',body:JSON.stringify(body)});
    $('#coachMode').textContent=`Teacher Soul · ${d.mode} · ${d.role} · ${d.phase} · help ${d.help_level}`;
    thread.insertAdjacentHTML('beforeend',`<div class="coach-msg">${escapeHtml(d.reply)}</div>`);thread.scrollTop=thread.scrollHeight;
    if(me.role==='learner')loadLearningModel(currentModule?.id);
  }catch(e){toast(e.message)}
}
function setupRecorder(){
  const btn=$('#recordBtn');if(!navigator.mediaDevices||!window.MediaRecorder){btn.disabled=true;$('#recordState').textContent='Recording unsupported in this browser';return}
  btn.onclick=async()=>{
    if(recorder&&recorder.state==='recording'){recorder.stop();btn.textContent='Start recording';return}
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});recordChunks=[];recorder=new MediaRecorder(stream);
    recorder.ondataavailable=e=>recordChunks.push(e.data);
    recorder.onstop=async()=>{stream.getTracks().forEach(t=>t.stop());const blob=new Blob(recordChunks,{type:recorder.mimeType||'audio/webm'});const file=new File([blob],`voice-reflection-${Date.now()}.webm`,{type:blob.type});const fd=new FormData();fd.append('file',file);fd.append('caption','Voice reflection');if(currentModule)fd.append('module_id',currentModule.id);await api('/api/uploads',{method:'POST',body:fd});$('#recordState').textContent='Saved';loadMedia()};
    recorder.start();btn.textContent='Stop recording';$('#recordState').textContent='Recording…'
  }
}

bind();init();
return {saveRun,setCoachContext};
})();
