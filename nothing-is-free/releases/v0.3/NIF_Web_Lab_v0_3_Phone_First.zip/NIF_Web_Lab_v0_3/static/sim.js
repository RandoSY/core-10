/* NIF Web Lab simulation engine. Deterministic-enough for learning, imperfect-enough for inquiry. */
window.NIFSim = (() => {
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const noise=(scale)=> (Math.random()*2-1)*scale;
  const fmt=(x,n=2)=>Number(x).toFixed(n);
  const el=(id)=>document.getElementById(id);

  function commonShell(title, question, controls, body){
    return `<div class="sim-grid"><div><p class="eyebrow">INQUIRY</p><h2 style="font-family:Georgia,serif;color:#17324d;margin:.2em 0">${title}</h2><p>${question}</p><div class="controls">${controls}</div></div><div>${body}</div></div>`;
  }
  function range(id,label,min,max,step,value,unit=''){
    return `<div class="control"><label for="${id}">${label}</label><output id="${id}Out">${value}${unit}</output><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></div>`;
  }
  function bindRange(id, unit, fn){const e=document.getElementById(id);const o=document.getElementById(id+'Out');e?.addEventListener('input',()=>{o.textContent=e.value+unit;fn();});}
  function saveButton(simType,getData){
    const btn=document.getElementById('saveRun'); if(!btn)return;
    btn.onclick=async()=>{const {inputs,outputs,title,elapsed_sim_s=0}=getData(); await window.NIFApp.saveRun({sim_type:simType,title,inputs,outputs,elapsed_sim_s});};
  }


  function phone(host){
    const controls=range('phoneStartSoc','Starting battery',5,90,1,22,'%')+
      range('phoneCapacity','Phone battery capacity',8,25,0.5,15.5,' Wh')+
      range('phoneCharger','Charger rating',5,65,1,20,' W')+
      range('phoneMinutes','Charging time',5,180,5,45,' min')+
      range('phoneRate','Electricity price',0.05,0.40,0.005,0.16,' $/kWh')+
      `<div class="control"><label>Phone use while charging</label><select id="phoneUse"><option value="0.25">Screen off / idle</option><option value="1.5">Normal use</option><option value="3.5">Video / game</option></select></div>`+
      `<button class="primary" id="phoneRun">Run charge</button><button class="secondary" id="phoneToFull">Charge to 100%</button><button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram phone-lab"><div class="phone-energy-chain"><div class="chain-box">WALL<br><b>AC</b></div><span>→</span><div class="chain-box">CHARGER<br><b id="phoneWallW">— W</b></div><span>→</span><div class="chain-meter"><small>USB ENERGY METER</small><strong id="phoneV">— V</strong><strong id="phoneA">— A</strong><strong id="phoneW">— W</strong><em id="phoneWh">— Wh</em></div><span>→</span><div class="phone-sim-device"><div class="phone-sim-battery"><i id="phoneFill"></i></div><b id="phonePct">—%</b><small>SIMULATED</small></div></div><div class="metrics" id="phoneMetrics"></div><div class="phone-ledger" id="phoneLedger"></div><p class="muted"><b>Model note:</b> this intentionally simplified phone model includes charger loss, battery-conversion loss, background phone load, and charge taper near full. It predicts a plausible experiment; it does not claim to reproduce a particular phone.</p></div>`;
    host.innerHTML=commonShell('Charge Your Phone','You do this almost every day. How much energy crosses the wall, how much reaches the battery, where does the rest go, and what does it cost?',controls,body);
    let data={};

    function simulate(minutesOverride=null){
      const start=+el('phoneStartSoc').value;
      const cap=+el('phoneCapacity').value;
      const charger=+el('phoneCharger').value;
      const rate=+el('phoneRate').value;
      const background=+el('phoneUse').value;
      const requested=minutesOverride===null?+el('phoneMinutes').value:minutesOverride;
      const adapterEta=clamp(.88 + .025*Math.min(charger,30)/30, .84, .915);
      const batteryEta=.90;
      let soc=start, usbWh=0, wallWh=0, storedWh=0, loadWh=0, t=0, lastP=0, lastV=5, lastI=0;
      const maxMin=minutesOverride===Infinity?360:requested;
      while(t<maxMin && soc<99.95){
        const taper=soc<50?1:soc<80?(1-.45*(soc-50)/30):Math.max(.12,.55-.43*(soc-80)/20);
        const usbP=Math.min(charger,22)*taper;
        const v=usbP>7.5?9.0:5.0;
        const acceptedP=Math.max(0,usbP*batteryEta-background);
        const dt=1/60;
        const remaining=cap*(100-soc)/100;
        const stored=Math.min(acceptedP*dt,remaining);
        const actualUsb=stored>0 ? Math.min(usbP*dt, (stored + background*dt)/batteryEta) : 0;
        storedWh+=stored; loadWh+=Math.min(background*dt,actualUsb*batteryEta); usbWh+=actualUsb; wallWh+=actualUsb/adapterEta;
        soc=clamp(start+storedWh/cap*100,0,100);
        t+=1; lastP=usbP; lastV=v; lastI=usbP/v;
        if(minutesOverride!==Infinity && t>=requested) break;
      }
      const loss=Math.max(0,wallWh-storedWh-loadWh);
      const cost=wallWh/1000*rate;
      el('phoneWallW').textContent=`${fmt(lastP/adapterEta,1)} W`;
      el('phoneV').textContent=`${fmt(lastV,2)} V`;
      el('phoneA').textContent=`${fmt(lastI,2)} A`;
      el('phoneW').textContent=`${fmt(lastP,1)} W`;
      el('phoneWh').textContent=`${fmt(usbWh,2)} Wh`;
      el('phonePct').textContent=`${fmt(soc,0)}%`;
      el('phoneFill').style.width=`${clamp(soc,2,100)}%`;
      el('phoneMetrics').innerHTML=[
        ['Wall energy',wallWh,'Wh',2],['USB energy',usbWh,'Wh',2],['Battery added',storedWh,'Wh',2],
        ['Phone use',loadWh,'Wh',2],['Losses',loss,'Wh',2],['Electricity cost',cost,'$',4]
      ].map(x=>`<div class="metric"><small>${x[0]}</small><b>${x[2]==='$'?'$':''}${fmt(x[1],x[3])} ${x[2]==='$'?'':x[2]}</b></div>`).join('');
      el('phoneLedger').innerHTML=`<b>Energy ledger</b><span>Wall ${fmt(wallWh,2)} Wh</span><i>→</i><span>USB ${fmt(usbWh,2)} Wh</span><i>→</i><span>Battery +${fmt(storedWh,2)} Wh</span><span>Phone operation ${fmt(loadWh,2)} Wh</span><span>Losses ${fmt(loss,2)} Wh</span>`;
      data={title:'Charge Your Phone',inputs:{starting_soc_pct:start,battery_capacity_Wh:cap,charger_rating_W:charger,requested_minutes:requested,electricity_rate_per_kWh:rate,background_load_W:background,assumed_adapter_efficiency:adapterEta,assumed_battery_path_efficiency:batteryEta},outputs:{ending_soc_pct:soc,elapsed_min:t,wall_input_Wh:wallWh,usb_output_Wh:usbWh,battery_energy_added_Wh:storedWh,phone_operating_Wh:loadWh,loss_Wh:loss,electricity_cost_USD:cost,last_usb_voltage_V:lastV,last_usb_current_A:lastI,last_usb_power_W:lastP},elapsed_sim_s:t*60};
      window.NIFApp.setCoachContext({...data,provenance:'SIMULATED',prompt:'Compare the wall energy, USB energy, and battery energy. Do not call a simulation output a physical measurement.'});
    }
    ['phoneStartSoc','phoneCapacity','phoneCharger','phoneMinutes','phoneRate'].forEach(id=>bindRange(id,id==='phoneStartSoc'?'%':id==='phoneCapacity'?' Wh':id==='phoneCharger'?' W':id==='phoneMinutes'?' min':' $/kWh',()=>simulate()));
    el('phoneUse').onchange=()=>simulate();
    el('phoneRun').onclick=()=>simulate();
    el('phoneToFull').onclick=()=>simulate(Infinity);
    simulate(); saveButton('phone',()=>data);
  }

  function ledger(host){
    host.innerHTML=commonShell('Energy Chain Builder','Can you account for every conversion without allowing energy to disappear?',
      `<button class="primary" id="ledgerRun">Run chain</button><button class="secondary" id="saveRun">Save run</button>`,
      `<div class="diagram"><div class="ledger-chain"><div class="node on">☀<br>Sun</div><div class="arrow">→</div><div class="node on">▦<br>Solar panel</div><div class="arrow">→</div><div class="node on">▣<br>USB Wh meter</div><div class="arrow">→</div><div class="node on">▤<br>Charger</div><div class="arrow">→</div><div class="node on">AA<br>Battery</div><div class="arrow">→</div><div class="node on">⚙<br>Robot</div></div><div id="ledgerMetrics" class="metrics"></div><p class="muted">Every stage has an efficiency. Loss is not missing energy: it usually becomes heat, sound, radiation, or unusable chemical/electrical energy.</p></div>`);
    let data={};
    function run(){
      const solar=18+noise(1.4), pv=.78+noise(.025), charge=.76+noise(.025), robot=.41+noise(.03);
      const elec=solar*pv, stored=elec*charge, work=stored*robot, loss=solar-work;
      data={inputs:{solar_Wh:solar,pv_eff:pv,charge_eff:charge,robot_useful_eff:robot},outputs:{panel_Wh:elec,stored_Wh:stored,useful_work_Wh:work,loss_Wh:loss,overall_eff:work/solar},title:'Complete energy ledger'};
      document.getElementById('ledgerMetrics').innerHTML=[['Source',solar,'Wh'],['Panel out',elec,'Wh'],['Stored',stored,'Wh'],['Useful work',work,'Wh'],['Losses',loss,'Wh'],['Overall',100*work/solar,'%']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${fmt(x[1],x[2]=='%'?1:2)} ${x[2]}</b></div>`).join('');
      window.NIFApp.setCoachContext(data);
    }
    document.getElementById('ledgerRun').onclick=run; run(); saveButton('ledger',()=>data);
  }

  function solar(host){
    const controls=range('irr','Irradiance',100,1100,10,850,' W/m²')+range('angle','Panel angle',0,85,1,20,'°')+range('shade','Shading',0,90,1,0,'%')+range('temp','Panel temp',0,70,1,35,'°C')+`<button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram"><div class="instrument"><small>USB POWER / ENERGY METER</small><div class="digits" id="solarDigits">0.00 W</div><div id="solarSub"></div></div><div class="metrics" id="solarMetrics"></div><svg viewBox="0 0 700 260" style="width:100%;margin-top:12px"><circle cx="100" cy="80" r="42" fill="#f2bd4a"/><g stroke="#e2a82b" stroke-width="4"><line x1="100" y1="15" x2="100" y2="0"/><line x1="35" y1="80" x2="15" y2="80"/><line x1="165" y1="80" x2="190" y2="80"/></g><g id="rays" stroke="#d9a01c" stroke-width="3" opacity=".65"><line x1="150" y1="105" x2="465" y2="180"/><line x1="150" y1="75" x2="475" y2="160"/><line x1="145" y1="130" x2="455" y2="200"/></g><g id="panelG" transform="translate(450,175) rotate(-20)"><rect x="-100" y="-30" width="200" height="60" rx="5" fill="#214a68" stroke="#102a42" stroke-width="4"/><g stroke="#80a6b8"><line x1="-50" y1="-28" x2="-50" y2="28"/><line x1="0" y1="-28" x2="0" y2="28"/><line x1="50" y1="-28" x2="50" y2="28"/></g></g></svg></div>`;
    host.innerHTML=commonShell('Solar Panel','What changes the electrical power available from the same nominal 5 W panel?',controls,body);
    let data={};
    function calc(){const G=+el('irr').value,a=+el('angle').value,s=+el('shade').value,t=+el('temp').value; const area=.035; const eta25=.18; const eta=eta25*(1-.004*Math.max(0,t-25)); const incident=G*area*Math.cos(a*Math.PI/180); const raw=incident*eta*(1-s/100); const p=clamp(raw+noise(.025),0,5.4); const v=clamp(5.15-.08*(p/5)+noise(.015),4.6,5.25); const i=p/v; const wh=p*1.0; document.getElementById('panelG').setAttribute('transform',`translate(450,175) rotate(${-a})`); el('solarDigits').textContent=`${fmt(p)} W`; el('solarSub').textContent=`${fmt(v)} V   ${fmt(i,3)} A`; el('solarMetrics').innerHTML=[['Incident',incident,'W'],['Electrical',p,'W'],['1-hour energy',wh,'Wh'],['Effective η',100*p/Math.max(.001,incident),'%']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${fmt(x[1],1)} ${x[2]}</b></div>`).join(''); data={title:'Solar panel inquiry',inputs:{irradiance_W_m2:G,angle_deg:a,shade_pct:s,panel_temp_C:t,area_m2:area},outputs:{incident_W:incident,electrical_W:p,voltage_V:v,current_A:i,energy_1h_Wh:wh}}; window.NIFApp.setCoachContext(data);}
    ['irr','angle','shade','temp'].forEach(id=>bindRange(id,id==='angle'?'°':id==='shade'?'%':id==='temp'?'°C':' W/m²',calc));calc();saveButton('solar',()=>data);
  }

  function battery(host){
    const controls=range('soc','Starting state of charge',0,100,1,20,'%')+range('chargeP','Charger input power',0.5,8,0.1,4.2,' W')+range('btemp','Battery temp',0,50,1,25,'°C')+`<button class="primary" id="chargeHour">Advance 1 hour</button><button class="secondary" id="resetBat">Reset</button><button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram"><div class="instrument"><small>4 × AA NiMH PACK</small><div class="digits" id="batDigits">4.80 V</div><div id="batSub"></div></div><div style="height:42px;border:2px solid #17324d;border-radius:8px;margin:24px 0;position:relative"><div id="batFill" style="height:100%;background:#69b99d;width:20%;border-radius:5px"></div></div><div class="metrics" id="batMetrics"></div></div>`;
    host.innerHTML=commonShell('Store the Sun','How much input energy becomes recoverable chemical energy in four AA NiMH cells?',controls,body);
    let initial=+el('soc').value, current=initial, inputWh=0, storedAdded=0, data={};
    function draw(){const p=+el('chargeP').value,t=+el('btemp').value; const capWh=4*1.2*2.8; const eta=clamp(.82-.002*Math.abs(t-25)-.025*Math.max(0,p-5),.55,.88); const v=4.55+1.05*(current/100)+noise(.015); el('batDigits').textContent=`${fmt(v)} V`;el('batSub').textContent=`SOC ${fmt(current,0)}% · nominal capacity ${fmt(capWh,2)} Wh`;el('batFill').style.width=`${current}%`;el('batMetrics').innerHTML=[['Input',inputWh,'Wh'],['Stored added',storedAdded,'Wh'],['Charge η',eta*100,'%'],['Capacity',capWh,'Wh']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${fmt(x[1],x[2]=='%'?1:2)} ${x[2]}</b></div>`).join(''); data={title:'NiMH charging inquiry',inputs:{starting_soc_pct:initial,charger_W:p,battery_temp_C:t},outputs:{ending_soc_pct:current,input_Wh:inputWh,stored_added_Wh:storedAdded,charge_efficiency:eta,nominal_capacity_Wh:capWh},elapsed_sim_s:inputWh/Math.max(.1,p)*3600};window.NIFApp.setCoachContext(data);}
    el('chargeHour').onclick=()=>{const p=+el('chargeP').value,t=+el('btemp').value,cap=13.44;const eta=clamp(.82-.002*Math.abs(t-25)-.025*Math.max(0,p-5),.55,.88);const accepted=Math.min(p*eta,cap*(100-current)/100); inputWh+=accepted/eta;storedAdded+=accepted;current=clamp(current+accepted/cap*100,0,100);el('soc').value=current;el('socOut').textContent=Math.round(current)+'%';draw();};el('resetBat').onclick=()=>{current=+el('soc').value;initial=current;inputWh=storedAdded=0;draw();};['soc','chargeP','btemp'].forEach(id=>bindRange(id,id==='soc'?'%':id==='btemp'?'°C':' W',()=>{if(id==='soc'&&inputWh===0){current=+el('soc').value;initial=current;}draw();}));draw();saveButton('battery',()=>data);
  }

  function robot(host){
    const controls=range('speed','Cruise speed',0.08,0.45,0.01,0.22,' m/s')+range('robotMass','Robot mass',0.35,1.0,0.01,0.62,' kg')+range('floor','Rolling resistance',0.01,0.12,0.005,0.035,'')+`<div class="control"><label>Navigation</label><select id="policy"><option value="random">Random avoidance</option><option value="energy" selected>Energy Explorer</option></select></div><div class="control"><label>Simulation speed</label><select id="simSpeed"><option value="1">1×</option><option value="10">10×</option><option value="100" selected>100×</option></select></div><button class="primary" id="robotStart">Start</button><button class="secondary" id="robotReset">Reset</button><button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram"><canvas id="robotCanvas" class="robot-world" width="800" height="470"></canvas><div class="metrics" id="robotMetrics"></div></div>`;
    host.innerHTML=commonShell('Energy Explorer','Does software change useful motion per watt-hour?',controls,body);
    const c=el('robotCanvas'),ctx=c.getContext('2d'); let state, timer=null,data={};
    const obstacles=[{x:300,y:80,w:130,h:55},{x:520,y:270,w:70,h:140},{x:120,y:300,w:120,h:45},{x:610,y:70,w:100,h:70}];
    function reset(){if(timer)clearInterval(timer);timer=null;state={x:100,y:150,a:0,wh:0,dist:0,t:0,turns:0,hits:0,best:0,run:0,sectors:Array.from({length:8},()=>({best:0,hits:0,visits:0}))};draw();}
    function ray(x,y,a,max=160){for(let d=0;d<=max;d+=4){const px=x+Math.cos(a)*d,py=y+Math.sin(a)*d;if(px<12||py<12||px>788||py>458)return d;for(const o of obstacles)if(px>o.x&&px<o.x+o.w&&py>o.y&&py<o.y+o.h)return d;}return max;}
    function collision(x,y){if(x<18||y<18||x>782||y>452)return true;return obstacles.some(o=>x>o.x-15&&x<o.x+o.w+15&&y>o.y-15&&y<o.y+o.h+15);}
    function choose(){const opts=[0,-Math.PI/4,Math.PI/4,-Math.PI/2,Math.PI/2];let best={score:-1e9,da:0};for(const da of opts){const r=ray(state.x,state.y,state.a+da);const sec=((Math.round((state.a+da)/(Math.PI/4))%8)+8)%8;const mem=state.sectors[sec];let score;if(el('policy').value==='energy')score=10*r+7*(mem.best*10)+400/(1+mem.visits)-35*mem.hits-18*Math.abs(Math.round(da/(Math.PI/4)));else score=r+Math.random()*180;if(score>best.score)best={score,da,sec,r};}state.a+=best.da;state.turns+=Math.abs(Math.round(best.da/(Math.PI/4)));state.sectors[best.sec].visits++;state.run=0;}
    function step(dt){const v=+el('speed').value,m=+el('robotMass').value,rr=+el('floor').value;const range=ray(state.x,state.y,state.a,100);if(range<24){state.hits++;const sec=((Math.round(state.a/(Math.PI/4))%8)+8)%8;state.sectors[sec].hits++;state.sectors[sec].best=Math.max(state.sectors[sec].best,state.run);state.best=Math.max(state.best,state.run);state.wh+=.0025;state.x-=Math.cos(state.a)*8;state.y-=Math.sin(state.a)*8;choose();return;}const nx=state.x+Math.cos(state.a)*v*dt*80,ny=state.y+Math.sin(state.a)*v*dt*80;if(collision(nx,ny)){state.hits++;choose();return;}state.x=nx;state.y=ny;const dm=v*dt;state.dist+=dm;state.run+=dt;state.t+=dt;const electronics=.23;const rolling=m*9.81*rr*v;const drivetrain=(rolling/.35)+.55;const turnPenalty=0;const power=electronics+drivetrain+turnPenalty;state.wh+=power*dt/3600;}
    function tick(){const mult=+el('simSpeed').value;for(let i=0;i<Math.max(1,mult/5);i++)step(.25);draw();}
    function draw(){ctx.clearRect(0,0,800,470);ctx.fillStyle='#e9efe8';ctx.fillRect(0,0,800,470);ctx.fillStyle='#d9c7a2';for(const o of obstacles)ctx.fillRect(o.x,o.y,o.w,o.h);ctx.strokeStyle='#b2bfc5';ctx.lineWidth=10;ctx.strokeRect(5,5,790,460);ctx.save();ctx.translate(state?.x||100,state?.y||150);ctx.rotate(state?.a||0);ctx.fillStyle='#c9483b';ctx.fillRect(-18,-12,36,24);ctx.fillStyle='#17324d';ctx.fillRect(10,-8,12,16);ctx.fillStyle='#222';ctx.fillRect(-12,-16,8,5);ctx.fillRect(-12,11,8,5);ctx.restore();if(!state)return;const mperwh=state.dist/Math.max(.0001,state.wh);el('robotMetrics').innerHTML=[['Sim time',state.t/3600,'h'],['Distance',state.dist,'m'],['Energy',state.wh,'Wh'],['Motion/energy',mperwh,'m/Wh'],['Turns',state.turns,''],['Obstacles',state.hits,'']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${fmt(x[1],x[2]=='h'?2:x[2]=='m'?1:2)} ${x[2]}</b></div>`).join('');data={title:`Robot ${el('policy').value} navigation`,inputs:{policy:el('policy').value,speed_m_s:+el('speed').value,mass_kg:+el('robotMass').value,rolling_resistance:+el('floor').value},outputs:{sim_time_s:state.t,distance_m:state.dist,energy_Wh:state.wh,meters_per_Wh:mperwh,turns:state.turns,obstacles:state.hits,longest_run_s:state.best},elapsed_sim_s:state.t};window.NIFApp.setCoachContext(data);}
    el('robotStart').onclick=()=>{if(timer){clearInterval(timer);timer=null;el('robotStart').textContent='Start'}else{timer=setInterval(tick,60);el('robotStart').textContent='Pause'}};el('robotReset').onclick=reset;['speed','robotMass','floor'].forEach(id=>bindRange(id,id==='speed'?' m/s':id==='robotMass'?' kg':'',draw));reset();saveButton('robot',()=>data);
  }

  function thermal(host){
    const controls=range('waterMass','Water mass',50,500,10,250,' g')+range('mwPower','Microwave wall power',500,1800,10,1100,' W')+range('mwTime','Heating time',10,300,5,90,' s')+range('mwEff','Water heating efficiency',35,85,1,62,'%')+`<button class="primary" id="heatBtn">Heat water</button><button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram"><div class="instrument"><small>AC WATT / ENERGY METER</small><div class="digits" id="mwDigits">0 Wh</div><div id="mwSub"></div></div><div class="metrics" id="mwMetrics"></div><div style="width:150px;height:190px;margin:30px auto 0;border:5px solid #abc6d1;border-top:0;border-radius:0 0 35px 35px;position:relative"><div id="waterCup" style="position:absolute;left:0;right:0;bottom:0;height:60%;background:#8cd1e8aa;border-radius:0 0 28px 28px"></div><div id="tempLabel" style="position:absolute;inset:0;display:grid;place-items:center;font-weight:850;font-size:28px;color:#17324d">20.0°C</div></div></div>`;
    host.innerHTML=commonShell('Microwave Water Heating','How much of the wall energy becomes thermal energy in the water?',controls,body);let data={};
    function calc(){const m=+el('waterMass').value/1000,p=+el('mwPower').value,t=+el('mwTime').value,eta=+el('mwEff').value/100;const inputJ=p*t, useful=inputJ*eta,delta=useful/(m*4184),tf=20+delta,wh=inputJ/3600;el('mwDigits').textContent=`${fmt(wh,2)} Wh`;el('mwSub').textContent=`${fmt(inputJ/1000,1)} kJ wall input`;el('tempLabel').textContent=`${fmt(tf,1)}°C`;el('mwMetrics').innerHTML=[['ΔT',delta,'°C'],['Water Q',useful/1000,'kJ'],['Wall energy',inputJ/1000,'kJ'],['Loss', (inputJ-useful)/1000,'kJ']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${fmt(x[1],1)} ${x[2]}</b></div>`).join('');data={title:'Microwave water heating',inputs:{water_mass_kg:m,wall_power_W:p,time_s:t,assumed_efficiency:eta,initial_C:20},outputs:{wall_input_J:inputJ,water_Q_J:useful,final_C:tf,delta_C:delta,wall_Wh:wh,loss_J:inputJ-useful},elapsed_sim_s:t};window.NIFApp.setCoachContext(data);}
    ['waterMass','mwPower','mwTime','mwEff'].forEach(id=>bindRange(id,id==='waterMass'?' g':id==='mwPower'?' W':id==='mwTime'?' s':'%',calc));el('heatBtn').onclick=calc;calc();saveButton('thermal',()=>data);
  }

  function bill(host){
    const controls=range('monthlyKwh','Monthly use',100,2000,10,850,' kWh')+range('energyRate','Energy charge',0.05,0.35,0.005,0.145,' $/kWh')+range('fixedCharge','Fixed monthly charge',0,50,1,18,' $')+range('riders','Riders/taxes',0,20,0.5,7.5,'%')+`<button class="secondary" id="saveRun">Save run</button>`;
    const body=`<div class="diagram"><div style="max-width:520px;margin:auto;background:#fff;border:1px solid #cfd9df;padding:25px;box-shadow:0 8px 30px rgba(0,0,0,.08)"><h3 style="margin-top:0">ELECTRIC SERVICE — SAMPLE BILL</h3><div id="billRows"></div></div><div class="metrics" id="billMetrics"></div></div>`;
    host.innerHTML=commonShell('From kWh to Dollars','Why are marginal cents/kWh and all-in average cents/kWh not always the same?',controls,body);let data={};
    function calc(){const k=+el('monthlyKwh').value,r=+el('energyRate').value,f=+el('fixedCharge').value,t=+el('riders').value/100;const energy=k*r,sub=energy+f,extra=sub*t,total=sub+extra,all=total/k;el('billRows').innerHTML=`<div class="list-row"><span>Energy ${k} kWh × $${fmt(r,3)}</span><b>$${fmt(energy)}</b></div><div class="list-row"><span>Fixed customer charge</span><b>$${fmt(f)}</b></div><div class="list-row"><span>Riders / taxes ${fmt(t*100,1)}%</span><b>$${fmt(extra)}</b></div><div class="list-row"><strong>Total</strong><strong>$${fmt(total)}</strong></div>`;el('billMetrics').innerHTML=[['Marginal rate',r*100,'¢/kWh'],['All-in avg.',all*100,'¢/kWh'],['1 robot charge (13.44Wh)',.01344*r,'$'],['1 kWh',all,'$']].map(x=>`<div class="metric"><small>${x[0]}</small><b>${x[2]=='$'?'$':''}${fmt(x[1],x[2]=='$'?4:2)} ${x[2]=='$'?'':x[2]}</b></div>`).join('');data={title:'Electricity bill inquiry',inputs:{monthly_kWh:k,energy_rate_per_kWh:r,fixed_charge:f,riders_tax_fraction:t},outputs:{energy_charge:energy,riders_taxes:extra,total_bill:total,all_in_rate_per_kWh:all}};window.NIFApp.setCoachContext(data);}
    ['monthlyKwh','energyRate','fixedCharge','riders'].forEach(id=>bindRange(id,id==='monthlyKwh'?' kWh':id==='energyRate'?' $/kWh':id==='fixedCharge'?' $':'%',calc));calc();saveButton('bill',()=>data);
  }

  const renderers={phone,ledger,solar,battery,robot,thermal,bill};
  function render(name,host){(renderers[name]||phone)(host)}
  return {render};
})();
