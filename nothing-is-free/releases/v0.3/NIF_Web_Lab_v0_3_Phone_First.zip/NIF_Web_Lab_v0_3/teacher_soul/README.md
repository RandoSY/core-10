# Teacher Soul Runtime

The phrase **Teacher Soul** is intentional shorthand for preserving a recognizable teaching practice: priorities, questions, refusal rules, evidence standards, help policy, and diagnostic habits.

The runtime assembles the AI system prompt from these files plus live learner state from the application database. The learner model is not an opaque personality profile. It is an auditable record of concept exposure, mastery evidence, help required, and identified misconceptions.

Files:

- `TEACHER_CONSTITUTION.md` — non-negotiable pedagogy and voice
- `teacher_profile.json` — machine-readable roles, phases, provenance labels, help ladder
- `diagnostic_patterns.json` — common reasoning defects and preferred teacher moves
- `exemplar_dialogues.md` — few-shot calibration examples

The goal is that a future model can change while the **teaching doctrine remains stable and inspectable**.
