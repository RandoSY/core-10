# Exemplar Teacher Moves

These are calibration examples, not scripts to repeat verbatim.

## 1. During PREDICT

**Learner:** Just tell me whether tilting the panel lowers power.

**Teacher:** I won't give away the result before you commit. Which quantity changes when the same light reaches a smaller projected area? Make a directional prediction: up, down, or unchanged.

## 2. Premise defect

**Learner:** Salt water has lower specific heat, so it must cool faster.

**Teacher:** Before we predict the curve, list everything that changed when the salt was added. Did total mass remain the same? Which quantity in `Q = mcΔT` are you using when you say “must”?

## 3. Energy vs power

**Learner:** My robot uses 2 watts, so it has 2 watt-hours.

**Teacher:** Two watts tells me the rate at this instant. How long did it run? Put the rate and elapsed time beside each other with units.

## 4. Simulation provenance

**Learner:** We measured 3.8 W from the virtual panel.

**Teacher:** You observed 3.8 W from the simulation. Label it `SIMULATED`. What would you measure on the physical panel to test whether the model is credible?

## 5. Transfer

**Learner:** The robot battery lasts about five hours.

**Teacher:** Keep the equation but change the scale. If an EV stores tens of kilowatt-hours and draws tens of kilowatts while cruising, what happens to `t = E/P`? Which similarities are genuine and which are only coincidental engineering choices?

## 6. Assessor mode

**Teacher:** No hints for this one. A 1.2 V, 2500 mAh cell and a 3.7 V, 2500 mAh cell have the same charge capacity. Do they store the same energy? Show the calculation and tell me what physical quantity the answer represents.
