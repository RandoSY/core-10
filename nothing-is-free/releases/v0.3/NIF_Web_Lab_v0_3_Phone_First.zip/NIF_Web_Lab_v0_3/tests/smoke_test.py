import os, tempfile, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

tmp = Path(tempfile.mkdtemp(prefix='nif_test_'))
os.environ['NIF_DB_PATH'] = str(tmp/'test.sqlite3')
os.environ['NIF_UPLOAD_DIR'] = str(tmp/'uploads')
os.environ['NIF_SECRET_KEY'] = 'test-secret'
os.environ['NIF_SEED_DEMO'] = '1'
os.environ.pop('OPENAI_API_KEY', None)

from fastapi.testclient import TestClient
from niflab.main import app

with TestClient(app) as client:
    r = client.get('/health'); assert r.status_code == 200 and r.json()['ok'] and r.json()['teacher_soul'] and r.json()['phone_first'] and r.json()['version']=='0.3.0'
    r = client.post('/api/auth/login', json={'email':'student@nif.local','password':'Learn2050!'})
    assert r.status_code == 200, r.text
    csrf = r.json()['csrf']; h={'X-CSRF-Token':csrf}

    r = client.get('/api/teacher-profile'); assert r.status_code == 200 and 'Experience Before Equation' in r.json()['mottos']
    r = client.get('/api/curriculum'); assert r.status_code == 200
    data = r.json(); nif = next(c for c in data['courses'] if c['slug']=='nif')
    assert len(nif['modules']) >= 15
    assert nif['modules'][0]['slug'] == 'phone-charge' and nif['modules'][0]['code'] == 'CORE10-3.00' and nif['modules'][0]['activity_type'] == 'phone'
    assert nif['modules'][1]['slug'] == 'ledger' and nif['modules'][1]['code'] == 'CORE10-3.01'
    module_id = nif['modules'][0]['id']

    r = client.get(f'/api/learning-model?module_id={module_id}'); assert r.status_code == 200
    assert len(r.json()['concepts']) >= 3

    r = client.post('/api/lab-runs', headers=h, json={
        'module_id':module_id,'sim_type':'phone','title':'smoke','inputs':{'x':1},'outputs':{'y':2},'elapsed_sim_s':1
    }); assert r.status_code == 200, r.text

    r = client.post('/api/journal', headers=h, json={'module_id':module_id,'title':'evidence','hypothesis':'h','observation':'o'}); assert r.status_code == 200

    r = client.post('/api/inquiry-cycles', headers=h, json={
        'module_id':module_id,'title':'cycle','prediction':'up','phase':'PREDICT','status':'active'
    }); assert r.status_code == 200, r.text
    cycle_id = r.json()['id']
    r = client.get('/api/inquiry-cycles'); assert any(x['id']==cycle_id for x in r.json()['cycles'])

    r = client.post('/api/coach', headers=h, json={
        'module_id':module_id,'message':'Just tell me what happens to the panel when I tilt it.',
        'context':{},'role':'socratic_coach','phase':'PREDICT','help_level':6
    }); assert r.status_code == 200 and r.json()['reply']
    assert r.json()['help_level'] <= 3  # phase cap must override requested full answer

    r = client.get('/api/dashboard'); assert r.json()['lab_runs'] == 1
    model = client.get(f'/api/learning-model?module_id={module_id}').json()
    assert any(c['exposure_count'] >= 1 for c in model['concepts'])

with TestClient(app) as teacher:
    r = teacher.post('/api/auth/login', json={'email':'teacher@nif.local','password':'Teach2050!'})
    assert r.status_code == 200
    csrf = r.json()['csrf']; h={'X-CSRF-Token':csrf}
    r = teacher.get('/api/instructor/roster'); assert r.status_code == 200
    learner = next(x for x in r.json()['learners'] if x['email']=='student@nif.local')
    r = teacher.get(f"/api/instructor/learner/{learner['id']}/model"); assert r.status_code == 200
    r = teacher.post('/api/instructor/assessment', headers=h, json={
        'learner_id':learner['id'],'concept_code':'energy_ledger','score':0.8,'independence':0.9,'notes':'smoke assessment'
    }); assert r.status_code == 200, r.text
    concepts = r.json()['model']['concepts']
    energy = next(c for c in concepts if c['code']=='energy_ledger')
    assert energy['mastery'] > 0

print('NIF Web Lab v0.3 Phone-First Teacher Soul smoke test: PASS')
